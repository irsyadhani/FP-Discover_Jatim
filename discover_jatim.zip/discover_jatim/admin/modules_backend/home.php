<!-- content -->
	<div class="container"  id="content_sidebar">
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-6">
				<div class="title-content">
					<strong>LOGIN ADMIN</strong>
					<small class="small-title-content">MANAGE YOUR WEBSITE</small>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-12">
				<div class="stores_letter">
					<form method="post" action="modules_backend/proses_login.php">
						<input class="input-1-full" type="text" name="administrator" placeholder="Administrator*" required>
						<input class="input-1-full" type="password" name="password" placeholder="Password*" required>
						<button type="submit" class="button_login">Login</button>
						<button type="reset" class="button_reset_login">Reset</button>
					</form>
				</div>
			</div>
		</div>
				
	</div>
	
	<!-- content -->