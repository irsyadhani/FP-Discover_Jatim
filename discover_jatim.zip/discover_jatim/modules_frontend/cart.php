<!-- content -->
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-12">
				<div class="title-content">
					<strong>CART</strong>
					<small class="small-title-content">YOU'VE GOT 1 ITEM IN THE CART</small>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-12">
				<div class="wishlist">
					<table class="table table-hover">
						<thead>
							<tr>
								<th>NO</th>
								<th></th>
								<th class="product_table">PRODUCT</th>
								<th>QUANTITY</th>
								<th>TOTAL</th>
							<tr>
						</thead>
						<tbody>
							<tr>
								<td width="8%">1.</td>
								<td class="product_table_img" width="15%">
									<img src="resources/images/APPLE-MacBook-Pro-13-3-Zoll.png">
								</td>
								<td class="product_table">
									<h2>MACBOOK PRO 13"</h2>
									<b>Rp 13,175 K</b><a>Rp 13,500 K</a>
								</td>
								<td width="15%">
									<input type="number" class="number_cart">
								</td>
								<td width="15%">Rp 13,175 K<span class="close_wish">&times;</span></td>
							<tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
				
	</div>
	
	<!-- content -->