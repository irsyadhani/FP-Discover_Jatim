<?php
	session_start();
	include("../database.php");
	
		$v_proc = $_REQUEST['proc'];
		
		switch($v_proc){
			case "add_image":
			
			$v_pic = "resources/images/profil_user/".$_FILES['picture']['name'];
			$tmp = $_FILES['picture']['tmp_name'];
			$type = $_FILES['picture']['type'] = ("png" && "jpeg" && "jpg" && "gif");
			move_uploaded_file($tmp, "../".$v_pic);
			
			$sql = $db->prepare("INSERT INTO user(picture) VALUES (:pictureParam)");
			
			$sql->bindParam(':pictureParam', $v_pic);
						
			$sql->execute();
			
			if($_FILES['picture']['name'] != ''){
				$_SESSION['pic'] = $v_pic;
				echo "
				<script>
					alert('Upload Images Succes');
					window.location.href='../index.php';
				</script>
				";
			}else{
				echo "
				<script>
					alert('Upload Images Failed');
					window.location.href='../index.php?p=regandlog';
				</script>
				";
			}
			
			break;
		}
		