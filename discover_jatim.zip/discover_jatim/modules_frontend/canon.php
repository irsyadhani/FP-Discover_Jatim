<!-- content -->
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		
		<div class="product_detail">
			<div class="row">
				<div class="col-6">
					<div class="disc_detail">5% OFF</div>
						<div class="contain2">
							<input type="radio" name="slide2" class="radio-nav2" id="nav-12" checked/>
							<input type="radio" name="slide2" class="radio-nav2" id="nav-22"/>
							<input type="radio" name="slide2" class="radio-nav2" id="nav-32"/>

							<ul class="slide2">
								<li class="slide-12">
									<div class="product">
									<img onclick="modalImages('myImg')" id="myImg" src="resources/images/CANON-EOS-700D-18-55mm-IS-STM-8-555x587.png" width="100%"/>
									</div>
								</li>
								<li class="slide-22">
									<div class="product">
									<img onclick="modalImages('myImg2')" id="myImg2" src="resources/images/CANON-EOS-600D-18-270mm-Objektiv-Filter-Tasche-3-555x587.png" width="100%"/>
									</div>
								</li>
								<li class="slide-32">
								<div class="product">
									<img onclick="modalImages('myImg3')" id="myImg3" src="resources/images/CANON-EOS-600D-18-270mm-Objektiv-Filter-Tasche-555x587.png" width="100%"/>
									</div>
								</li>
								<div id="myModal" class="modal">
								  <span class="close">&times;</span>
								  <img class="modal-content" id="img01">
								</div>
							</ul>


							<div class="nav-arrow2 nav-next2">
								<label class="nav-12" for="nav-12">></label>
								<label class="nav-22" for="nav-22">></label>
								<label class="nav-32" for="nav-32">></label>
							</div>
							<div class="nav-arrow2 nav-prev2">
								<label class="nav-12" for="nav-12"><</label>
								<label class="nav-22" for="nav-22"><</label>
								<label class="nav-32" for="nav-32"><</label>
							</div>
						</div>
					</div>
				<div class="col-6">
					<div class="product_info">
						<strong>CANON EOS 600D</strong>
						<small class="small-title-content"><a href="">CAMERA</a></small>
					</div>
					<div class="description">
						<p><b>Processor :</b> Quad-Core</p>
						<p><b>Clock frequency :</b> 2.5 GHz</p>
						<p><b>Memory capacity :</b> 16 GB</p>
						<p><b>Slot for memory cards :</b> yes</p>
						<p><b>Amount of memory (RAM) :</b> 2 GB</p>

					</div>
					<div class="price_detail">
						<p><h1>Rp. 13,175 K<a>Rp. 13,500 K</a></h1></p>
					</div>
					<div class="form_add_cart">
						<form>
						<input type="number">
						<button type="submit">+ ADD TO CART</button>
						</form>
					</div>
				</div>
			</div>
		
		
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-12">
				<div class="news_comment">
					<div class="title-comment">
						<h2>ADD A REVIEW</h2>
					</div>
					<div>
						<form>
						<span class="rating">
							<input type="radio" class="rating-input" id="rating-input-1-5" name="rating-input-1" required/>
							<label for="rating-input-1-5" class="rating-star"></label>
							<input type="radio" class="rating-input" id="rating-input-1-4" name="rating-input-1" required/>
							<label for="rating-input-1-4" class="rating-star"></label>
							<input type="radio" class="rating-input" id="rating-input-1-3" name="rating-input-1" required/>
							<label for="rating-input-1-3" class="rating-star"></label>
							<input type="radio" class="rating-input" id="rating-input-1-2" name="rating-input-1" required/>
							<label for="rating-input-1-2" class="rating-star"></label>
							<input type="radio" class="rating-input" id="rating-input-1-1" name="rating-input-1" required/>
							<label for="rating-input-1-1" class="rating-star"></label>
						</span>
						<textarea class="textarea-big" type="text" placeholder="Your Review :" required></textarea>
						<input class="input-1_news" type="text" placeholder="Name*" required>
						<input class="input-2_news" type="email" placeholder="E-mail*" required>
						<button type="reset" class="button_comment_product_reset">Reset</button>
						<button type="submit" class="button_comment_product">Submit</button>
						</form>
					</div>
					<div class="title-comment_reviews">
						<h2>2 REVIEWS</h2>
					</div>
					<div class="fill_reviews">
						<span class="rating_name">
							<input type="radio" class="rating-input" id="rating-input-1-5" name="rating-input-1" />
							<label for="rating-input-1-5" class="rating-star"></label>
							<input type="radio" class="rating-input" id="rating-input-1-4" name="rating-input-1" />
							<label for="rating-input-1-4" class="rating-star"></label>
							<input type="radio" class="rating-input" id="rating-input-1-3" name="rating-input-1" />
							<label for="rating-input-1-3" class="rating-star"></label>
							<input type="radio" class="rating-input" id="rating-input-1-2" name="rating-input-1" />
							<label for="rating-input-1-2" class="rating-star"></label>
							<input type="radio" class="rating-input" id="rating-input-1-1" name="rating-input-1" />
							<label for="rating-input-1-1" class="rating-star"></label>
						</span>
						<div class="name_review">
						<img src="resources/images/1020_1.png"><h4 class="name_comment">Sandra Bullock</h4>
						</div>
						<div class="comment_review">
						TEST
						</div>
					</div>
					<div class="fill_reviews">
						<span class="rating_name">
							<input type="radio" class="rating-input" id="rating-input-1-5" name="rating-input-1" />
							<label for="rating-input-1-5" class="rating-star"></label>
							<input type="radio" class="rating-input" id="rating-input-1-4" name="rating-input-1" />
							<label for="rating-input-1-4" class="rating-star"></label>
							<input type="radio" class="rating-input" id="rating-input-1-3" name="rating-input-1" />
							<label for="rating-input-1-3" class="rating-star"></label>
							<input type="radio" class="rating-input" id="rating-input-1-2" name="rating-input-1" />
							<label for="rating-input-1-2" class="rating-star"></label>
							<input type="radio" class="rating-input" id="rating-input-1-1" name="rating-input-1" />
							<label for="rating-input-1-1" class="rating-star"></label>
						</span>
						<div class="name_review">
						<img src="resources/images/1020_2.png"><h4 class="name_comment">Angelina</h4>
						</div>
						<div class="comment_review">
						This was great!
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	</div>
	
	<!-- content -->