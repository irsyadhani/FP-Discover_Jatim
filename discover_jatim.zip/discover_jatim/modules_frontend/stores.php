
	<!-- content -->
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-6">
				<div class="title-content">
					<strong>GET IN TOUCH</strong>
					<small class="small-title-content">WRITE US A LETTER</small>
				</div>
			</div>
			<div class="col-6">
				<div class="title-content">
					<strong>OUR ADDRESS</strong>
					<small class="small-title-content">WHERE ARE WE LOCATED</small>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-6">
				<div class="stores_letter">
					<form method="post" action="modules_frontend/proses_cns.php">
						<input type="hidden" name="proc" value="add">
						<input class="input-1" type="text" name="name" placeholder="Name*" required>
						<input class="input-2" type="text" name="subject" placeholder="Subject*" required>
						<input class="input-1-full" type="email" name="email" placeholder="E-mail*" required>
						<textarea class="textarea-big" type="text" name="message" placeholder="Message*" required></textarea>
						<button type="reset" class="button_comment_reset">Reset</button>
							<button type="submit" class="button_comment">Send Message</button>						
					</form>
				</div>
			</div>
			<div class="col-6">
				<div class="stores_letter">
					<p>61253 Perintis 3 Street No.17,</p>
					<p>Sidoarjo, East Java,</p>
					<p class="country">Indonesia.</p>
					<p>(031) - 772000</p>
					<p class="country">irzstore.com</p>
					<p class="country">OUR SOCIAL :</p>
					<img src="resources/images/icon/facebook.png">
					<img src="resources/images/icon/instagram.png">
					<img src="resources/images/icon/twitter.png">
					<img src="resources/images/icon/youtube.png">
				</div>
			</div>
		</div>
				
	</div>
	
	<!-- content -->