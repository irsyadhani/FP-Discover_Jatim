<?php
	if(@$_GET['idcomment'] !=""){
		$idNews = base64_decode(@$_GET['idcomment']);
	}elseif(@$_GET['idreview'] !=""){
		$idReview = base64_decode(@$_GET['idreview']);
	}
	session_start();
	include("../database.php");
	
	
	$v_username	= addslashes($_POST['username']);
	$v_password	= addslashes($_POST['password']);
	
	$sql = $db->prepare("SELECT * FROM user WHERE username='$v_username' AND password='$v_password'");
	$sql->execute();
	$cek = $sql->rowCount();
	$hasil = $sql->fetch(PDO::FETCH_ASSOC);
	
	if($cek > 0){
		$_SESSION['username'] = $v_username;
		$_SESSION['email'] = @$hasil['email'];
		$_SESSION['picture'] = @$hasil['picture'];
		
		if(@$_GET['idcomment'] != ""){
			echo "
			<script>
				alert('Login Succes');
				window.location.href='../index.php?p=news_detail&id=".base64_encode($idNews)."';
			</script>
			";
		}elseif(@$_GET['idreview'] != ""){
			echo "
			<script>
				alert('Login Succes');
				window.location.href='../index.php?p=product_detail&id=".base64_encode($idReview)."';
			</script>
			";
		}else{
			echo "
			<script>
				alert('Login Succes');
				window.location.href='../index.php';
			</script>
			";
		}		
	}else{
		if(@$_GET['idcomment'] !=""){
			echo "
			<script>
				alert('Login Failed');
				window.location.href='index.php?p=regandlog&idcomment=".base64_encode($idNews)."';
			</script>
			";
		}elseif(@$_GET['idreview'] !=""){
			echo "
			<script>
				alert('Login Failed');
				window.location.href='../index.php?p=regandlog&idreview=".base64_encode($idReview)."';
			</script>
			";
		}else{
			echo "
			<script>
				alert('Login Failed');
				window.location.href='../index.php?p=regandlog';
			</script>
			";
		}
	}
?>