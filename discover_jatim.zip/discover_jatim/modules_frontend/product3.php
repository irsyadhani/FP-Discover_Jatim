<!-- content -->
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-12">
				<div class="title-content">
					<strong>PRODUCT	</strong>
					<small class="small-title-content">CHECK IT OUT NOW</small>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/glasses_1-826x1024.jpg" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">PURE GLASSES</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">BOBBLE</a></span>
							<h3 class="price">Rp 192,000</h3>
						</div>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/HTC-One-M8-glacial-silver.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">HTC ONE V8J</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">RING</a></span>
							<h3 class="price">Rp 7,799,000</h3>
						</div>
						<span class="sale">SALE!</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/red_earring.jpg" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">ORANGE AGATE</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">EARRING</a></span>
							<h3 class="price">Rp 120,000</h3>
						</div>
						<span class="sale">SALE!</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/image1xxl-12-290x370.jpg" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">OPEN ENDED FINE</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">BACKPACKER</a></span>
							<h3 class="price">Rp 782,000</h3>
						</div>
						<span class="disc">30% OFF</span>
					</div>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/image1xxl-13-290x370.jpg" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">TWO TIGER RING</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">RING</a></span>
							<h3 class="price">Rp 355,000</h3>
						</div>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/NOKIA-Lumia-735-dark-grey-290x200.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">NOKIA LUMIA 735</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">RING</a></span>
							<h3 class="price">Rp 4,500,000</h3>
						</div>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/image1xxl7-290x370 (2).jpg" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">TAJA DISC EARRINGS</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">RING</a></span>
							<h3 class="price">Rp 284,000</h3>
						</div>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/image1xxl-11-290x370 (1).jpg" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">OASIS ETCHED</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">RING</a></span>
							<h3 class="price">Rp 198,000</h3>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/HP-17-F031NG-I5-290x200.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">HP PAVILION G4-1311AU</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">EARRING</a></span>
							<h3 class="price">Rp 7,735,000</h3>
						</div>
						<span class="sale">SALE!</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/image1xxl-17-290x370.jpg" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">RHODIUM SPIKE</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">JACKET</a></span>
							<h3 class="price">Rp 140,000</h3>
						</div>
						<span class="featured">FEATURED</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/image1xxl19-290x370.jpg" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">OLIVIA BURTON DOT </a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">BACKPACKER</a></span>
							<h3 class="price">Rp 1,200,000</h3>
						</div>
						<span class="disc">30% OFF</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/small_ring.jpg" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">DOUBLE STONE RING</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">RING</a></span>
							<h3 class="price">Rp 156,000</h3>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/MICROSOFT-Xbox-360-500GB-inkl-1-290x200.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">XBOX 360</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">SHIRT</a></span>
							<h3 class="price">Rp 3,050,000</h3>
						</div>
						<span class="featured">FEATURED</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/vintage.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">VINTAGE</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">SHIRT</a></span>
							<h3 class="price">Rp 284,000</h3>
						</div>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/BOSE-QuietComfort-25-schwarz-blau-1-290x200.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">BOSE QuietComfort 25</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">JACKET</a></span>
							<h3 class="price">Rp 500,000</h3>
						</div>
						<span class="featured">FEATURED</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/mango.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">MANGO</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">SWEATER</a></span>
							<h3 class="price">Rp 298,000</h3>
						</div>
					</div>
				</div>
			</div>
		</div>
				
		
		<div class="row">
			<div class="col-12">
				<div class="pagination">
					<a href="index.php?p=product2">&laquo;</a>
					<a href="index.php?p=product">1</a>
					<a href="index.php?p=product2">2</a>
					<a href="index.php?p=product3" class="active">3</a>
					<a href="#">&raquo;</a>
				</div>
			</div>
		</div>
	
	</div>
	
	<!-- content -->