<?php
	include("../database.php");
	
	$v_proc = $_REQUEST['proc'];
	
	switch($v_proc){
		case "add":
		
			$v_name = $_POST['name'];
			$v_subject = $_POST['subject'];
			$v_email = $_POST['email'];
			$v_message = $_POST['message'];
			
			$sql = $db->prepare("INSERT INTO crinsug(name, subject, email, message) VALUES (:nameParam, :subjectParam, :emailParam, :messageParam)");
			
			$sql->bindParam(':nameParam', $v_name);
			$sql->bindParam(':subjectParam', $v_subject);
			$sql->bindParam(':emailParam', $v_email);
			$sql->bindParam(':messageParam', $v_message);
			
			$sql->execute();
			
			echo"
				<script>
					alert('Send Success');
					window.location.href='../index.php?p=stores';
				</script>
			";
	break;
	}