<!-- footer -->
	<footer>
		<div class="container">
			<div class="row">
				<div class="col-2">
					<nav class="nav2">
						<li class="title-footer">WHAT'S HOT</li>
						<li><a href="">DISCOUNT VOUCHER</a></li>
						<li><a href="index.html">TOP RATED</a></li>
						<li><a href="index.html">BEST SELLERS</a></li>
						<li><a href="index.html">VIEWERS</a></li>
					</nav>				
				</div>
				<div class="col-2">
					<nav class="nav2">
						<li class="title-footer">BRANDS</li>
						<li><a href="index.html">SAMSUNG</a></li>
						<li><a href="index.html">ZARA</a></li>
						<li><a href="index.html">NIKE</a></li>
						<li><a href="index.html">ADIDAS</a></li>
					</nav>	
				</div>
				<div class="col-2">
					<nav class="nav2">
						<li class="title-footer">MEN SHOP</li>
						<li><a href="men.html">TOPS</a></li>
						<li><a href="men.html">BOTTOM</a></li>
						<li><a href="men.html">ACCESSORIES</a></li>
						<li><a href="men.html">SHOES</a></li>
					</nav>	
				</div>
				<div class="col-2">
					<nav class="nav2">
						<li class="title-footer">WOMEN SHOP</li>
						<li><a href="women.html">JEANS</a></li>
						<li><a href="women.html">DRESSED</a></li>
						<li><a href="women.html">ACCESSORIES</a></li>
						<li><a href="women.html">SHOES</a></li>
					</nav>	
				</div>
				<div class="col-2">
					<nav class="nav2">
						<li class="title-footer">HELP</li>
						<li><a href="">F.A.Q.</a></li>
						<li><a href="">CONTACT US</a></li>
						<li><a href="">SHIPPING</a></li>
						<li><a href="">PRIVACY POLICY</a></li>
					</nav>	
				</div>
				<div class="col-2">
					<nav class="nav2">
						<li class="title-footer">SOCIAL</li>
						<img src="resources/images/icon/facebook.png">
						<img src="resources/images/icon/instagram.png">
						<img src="resources/images/icon/twitter.png">
						<img src="resources/images/icon/youtube.png">
					</nav>	
				</div>
			</div>
			<div class="row">
				<div class="col-12">
					<div class="trash-footer">
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-6">
					<div class="bottom-footer">
					Copyright &copy; 2017 - IRZ STORE
					<li class="bottom-footer2"><a href="">Privacy & Cookies</a><span class="sep">|</span><a href="">Term & Condition</a><span class="sep">|</span><a href="">Accessibility</a><span class="sep">|</span><a href="">Store</a><span class="sep">|</span><a href="">Directory</a><span class="sep">|</span><a href="">About Us</a></li>
					</div>
					
				</div>
				<div class="col-6">
					<div class="shipping_logo">
						<img src="resources/images/transfer_shipping/dhl.png" width="73" height="10">
						<img src="resources/images/transfer_shipping/j&t.png" width="50" height="30">
						<img src="resources/images/transfer_shipping/jne.png" width="60" height="20">
						<img src="resources/images/transfer_shipping/mastercard.png" width="28" height="17">
						<img src="resources/images/transfer_shipping/posindonesia.png" width="35" height="24">
						<img src="resources/images/transfer_shipping/tiki.png" width="40" height="35">
						<img src="resources/images/transfer_shipping/visa.png" width="38" height="11">
					</div>
				</div>
			</div>
		</div>
	</footer>
	<a href="#" class="ScrollToTop">TOP</a>
	<!-- footer -->
	
	<script src="includes/frontend/js/jquery.min.js"></script>
	<script>
$(document).on("scroll" ,function(){
		if($(document).scrollTop()>10){
			$("header").removeClass("large").addClass("small");
		}else{
			$("header").removeClass("small").addClass("large")
		}	
	});
	
$(document).ready(function(){
	$(window).scroll(function(){
		if($(this).scrollTop() > 450){
			$('.scrollToTop').fadeIn();
		}else{
			$('.scrollToTop').fadeOut();
		}
		});
		
		$('.scrollToTop').click(function(){
			$('html, body').animate({scrollTop : 0}, 800);
			return false;
		});
	});

	function modalImages(_sources){
		var modal = document.getElementById("myModal");
		var img = document.getElementById(_sources);
		var modalImg = document.getElementById("img01");
		modal.style.display = "block";
		modalImg.src = img.src;
		var span = document.getElementsByClassName("close")[0];
		span.onclick = function() { 
			modal.style.display = "none";
	}
	}
	</script>
</body>
</html>