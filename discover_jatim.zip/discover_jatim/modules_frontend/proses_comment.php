<?php
	include('../database.php');
		
	$v_proc = $_REQUEST['proc'];
	
	switch($v_proc){
		case "add":
		$v_id_news = $_POST['id_news'];
		$v_message = $_POST['message'];
		$v_email = $_POST['email'];
		$v_user = $_POST['user'];
		$v_picture = $_POST['picture'];
				
		$sql = $db->prepare("INSERT INTO comment(id_news, user, email, message, picture) VALUES(:id_newsParam, :userParam, :emailParam, :messageParam, :pictureParam)");
		
		$sql->bindParam(':id_newsParam', $v_id_news);
		$sql->bindParam(':userParam', $v_user);
		$sql->bindParam(':emailParam', $v_email);
		$sql->bindParam(':messageParam', $v_message);
		$sql->bindParam(':pictureParam', $v_picture);
		
		$sql->execute();
		
		echo"
			<script>
				window.location.href='../index.php?p=news_detail&id=".base64_encode($v_id_news)."';
			</script>
		";
	break;
	}