
	<!-- content -->
	<div class="container">
		<div class="row">
			<div class="col-8">
				<div class="banner-up-center">
					<img src="resources/images/banner/street.jpg">
					<span class="tooltip"><a href=""><b>SHOP NOW</b></a></span>
				</div>
			</div>
			<div class="col-4">
				<div class="banner-up">
					<img src="resources/images/banner/watch.jpg">
					<span class="tooltip"><a href=""><b>SHOP NOW</b></a></span>
				</div>
				<div class="banner-up2">
					<img src="resources/images/banner/sneakers.jpg">
					<span class="tooltip"><a href=""><b>SHOP NOW</b></a></span>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-12">
				<div class="title-content">
					<strong>MEN	</strong>
					<small class="small-title-content">CHECK IT OUT NOW BRO!</small>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/backpacker.png" width="263" height="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">BACKPACKER GREY</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">BACKPACKER</a></span>
							<h3 class="price">Rp 294 K</h3>
						</div>
						<span class="disc">30% OFF</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/image_glasses.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">GLASSES</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">ACCESSORIES</a></span>
							<h3 class="price">Rp 79 K</h3>
						</div>
						<span class="sale">SALE!</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/BEATS-Beats-by-Dr.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">BEATS BY DRE</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">HEADPHONE</a></span>
							<h3 class="price">Rp 700 K</h3>
						</div>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/asap_bag.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">ASAP BAG</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">BAG</a></span>
							<h3 class="price">Rp 405 K</h3>
						</div>
						<span class="disc">10% OFF</span>
					</div>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/image1xxl-119-290x370.jpg" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">BELFAST ROSE GOLD</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">JACKET</a></span>
							<h3 class="price">Rp 2,900 K</h3>
						</div>
						<span class="featured">FEATURED</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/dkny.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">DKNY</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">BAG</a></span>
							<h3 class="price">Rp 700 K</h3>
						</div>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/barcelet.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">PAUL SMITH</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">BARCELET</a></span>
							<h3 class="price">Rp 90 K</h3>
						</div>
						<span class="featured">FEATURED</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/watch_product.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">STONE DETAIL</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">WIRSTWATCH</a></span>
							<h3 class="price">Rp 200 K</h3>
						</div>
						<span class="disc">50% OFF</span>
					</div>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/BOSE-QuietComfort-25-schwarz-blau-1-290x200.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">BOSE QuietComfort 25</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">JACKET</a></span>
							<h3 class="price">Rp 500 K</h3>
						</div>
						<span class="featured">FEATURED</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/bobble.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">BOBBLE BENIE</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">BOBBLE</a></span>
							<h3 class="price">Rp 110 K</h3>
						</div>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/rayban_classic.jpg" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">RAYBAN CLASSIC</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">BACKPACKER</a></span>
							<h3 class="price">Rp 210 K</h3>
						</div>
						<span class="disc">30% OFF</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/skull.png" width="263" height="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">SKULL RING</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">RING</a></span>
							<h3 class="price">Rp 365 K</h3>
						</div>
					</div>
				</div>
			</div>
		</div>
			
		<div class="row">
			<div class="col-12">
				<div class="pagination">
					<a href="#">&laquo;</a>
					<a href="#" class="active">1</a>
					<a href="#">2</a>
					<a href="#">3</a>
					<a href="#">&raquo;</a>
				</div>
			</div>
		</div>
	
	</div>
	
	<!-- content -->