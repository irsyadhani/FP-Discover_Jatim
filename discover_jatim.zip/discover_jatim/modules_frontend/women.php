
	<!-- content -->
	<div class="container">
		<div class="row">
			<div class="col-4">
				<div class="banner-up">
					<img src="resources/images/banner/bohemian.jpg">
					<span class="tooltip"><a href=""><b>SHOP NOW</b></a></span>
				</div>
				<div class="banner-up2">
					<img src="resources/images/banner/high_heels.jpg">
					<span class="tooltip"><a href=""><b>SHOP NOW</b></a></span>
				</div>
			</div>
			<div class="col-4">
				<div class="banner-center">
					<img src="resources/images/banner/beauty.jpg">
					<span class="tooltip"><a href=""><b>SHOP NOW</b></a></span>
				</div>
			</div>
			<div class="col-4">
				<div class="banner-center">
					<img src="resources/images/banner/hair.jpg">
					<span class="tooltip"><a href=""><b>SHOP NOW</b></a></span>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-12">
				<div class="title-content">
					<strong>WOMEN</strong>
					<small class="small-title-content">LET'S SHOPPING GIRLS!</small>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/dkny.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">DKNY</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">BAG</a></span>
							<h3 class="price">Rp 700 K</h3>
						</div>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/lylescott.png" width="263" height="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">LYLESCOTT</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">BAGS</a></span>
							<h3 class="price">Rp 255 K</h3>
						</div>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/barcelet.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">PAUL SMITH</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">BARCELET</a></span>
							<h3 class="price">Rp 90 K</h3>
						</div>
						<span class="featured">FEATURED</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/jenga.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">JENGA</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">SHOES</a></span>
							<h3 class="price">Rp 300 K</h3>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/festival.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">FESTIVAL STONE</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">BARCELET</a></span>
							<h3 class="price">Rp 180 K</h3>
						</div>
						<span class="sale">SALE!</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/image_glasses.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">GLASSES</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">ACCESSORIES</a></span>
							<h3 class="price">Rp 79 K</h3>
						</div>
						<span class="sale">SALE!</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/ring_tiger.jpg" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">BILL SKINNER TIGER </a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">RING</a></span>
							<h3 class="price">Rp 800 K</h3>
						</div>
						<span class="sale">SALE!</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/image1xxl17-290x370.jpg" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">AQUA WRAP STONE </a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">SHIRT</a></span>
							<h3 class="price">Rp 558 K</h3>
						</div>
						<span class="featured">FEATURED</span>
					</div>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/watch_product.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">STONE DETAIL</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">WIRSTWATCH</a></span>
							<h3 class="price">Rp 200 K</h3>
						</div>
						<span class="disc">50% OFF</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/butterfly.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">BUTTERFLY</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">EARRING</a></span>
							<h3 class="price">Rp 120 K</h3>
						</div>
						<span class="sale">SALE!</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/backpacker.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">BACKPACKER GREY</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">BACKPACKER</a></span>
							<h3 class="price">Rp 294 K</h3>
						</div>
						<span class="disc">30% OFF</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/mango.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">MANGO</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">SWEATER</a></span>
							<h3 class="price">Rp 298 K</h3>
						</div>
					</div>
				</div>
			</div>
		</div>
			
		<div class="row">
			<div class="col-12">
				<div class="pagination">
					<a href="#">&laquo;</a>
					<a href="#" class="active">1</a>
					<a href="index.php?p=women2">2</a>
					<a href="#">3</a>
					<a href="index.php?p=women2">&raquo;</a>
				</div>
			</div>
		</div>
	
	</div>
	
	<!-- content -->