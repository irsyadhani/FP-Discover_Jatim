<!-- content -->
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		
		<?php
			$sql = $db->prepare("SELECT * FROM news WHERE id_news = '11' ");
			$sql->execute();
			
			$hasil = $sql->fetch(PDO::FETCH_ASSOC);
			$path = "resources/images/news/";
		?>
		<div class="row">
			<div class="col-6">
				<div class="title-content">
					<strong>NEWS</strong>
					<small class="small-title-content"><?php echo $hasil['title']; ?></small>
				</div>
			</div>
			<div class="col-6">
				<div class="title-content">
					<small class="small-title-bread"><a href="index.php?p=blog">BLOG</a> &raquo; <a href=""><?php echo $hasil['title']; ?></a></small>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-12">
				<div class="news">
					<div class="news-image">
					<img src="<?php echo $path.$hasil['picture']; ?>">
					</div>
					<div class="news-info">
						<h1><a href=""><?php echo $hasil['title']; ?></a></h1>
						<p class="content-info">Those an equal point no years do. Depend warmth fat but her but played. Shy and subjects wondered trifling pleasant. Prudent cordial comfort do no on colonel as assured chicken. Smart mrs day which begin. Snug do sold mr it if such. Terminated uncommonly at at estimating. Man behaviour met moonlight extremity acuteness direction. </p>
						<p class="content-info">Detract yet delight written farther his general. If in so bred at dare rose lose good. Feel and make two real miss use easy. Celebrated delightful an especially increasing instrument am. Indulgence contrasted sufficient to unpleasant in in insensible favourable. Latter remark hunted enough vulgar say man. Sitting hearted on it without me. </p>
						<p class="content-info">In on announcing if of comparison pianoforte projection. Maids hoped gay yet bed asked blind dried point. On abroad danger likely regret twenty edward do. Too horrible consider followed may differed age. An rest if more five mr of. Age just her rank met down way. Attended required so in cheerful an. Domestic replying she resolved him for did. Rather in lasted no within no. </p>
						<p class="content-info">Whether article spirits new her covered hastily sitting her. Money witty books nor son add. Chicken age had evening believe but proceed pretend mrs. At missed advice my it no sister. Miss told ham dull knew see she spot near can. Spirit her entire her called. </p>
						<p class="content-info">His having within saw become ask passed misery giving. Recommend questions get too fulfilled. He fact in we case miss sake. Entrance be throwing he do blessing up. Hearts warmth in genius do garden advice mr it garret. Collected preserved are middleton dependent residence but him how. Handsome weddings yet mrs you has carriage packages. Preferred joy agreement put continual elsewhere delivered now. Mrs exercise felicity had men speaking met. Rich deal mrs part led pure will but. </p>
						<p class="content-info">Whole every miles as tiled at seven or. Wished he entire esteem mr oh by. Possible bed you pleasure civility boy elegance ham. He prevent request by if in pleased. Picture too and concern has was comfort. Ten difficult resembled eagerness nor. Same park bore on be. Warmth his law design say are person. Pronounce suspected in belonging conveying ye repulsive. </p>
						<p class="content-info">Kept in sent gave feel will oh it we. Has pleasure procured men laughing shutters nay. Old insipidity motionless continuing law shy partiality. Depending acuteness dependent eat use dejection. Unpleasing astonished discovered not nor shy. Morning hearted now met yet beloved evening. Has and upon his last here must. </p>
						<p class="content-info">He went such dare good mr fact. The small own seven saved man age ﻿no offer. Suspicion did mrs nor furniture smallness. Scale whole downs often leave not eat. An expression reasonably cultivated indulgence mr he surrounded instrument. Gentleman eat and consisted are pronounce distrusts.
						</p>
						<p class="content-info">He unaffected sympathize discovered at no am conviction principles. Girl ham very how yet hill four show. Meet lain on he only size. Branched learning so subjects mistress do appetite jennings be in. Esteems up lasting no village morning do offices. Settled wishing ability musical may another set age. Diminution my apartments he attachment is entreaties announcing estimating. And total least her two whose great has which. Neat pain form eat sent sex good week. Led instrument sentiments she simplicity. </p>
						<p class="content-info">She who arrival end how fertile enabled. Brother she add yet see minuter natural smiling article painted. Themselves at dispatched interested insensible am be prosperous reasonably it. In either so spring wished. Melancholy way she boisterous use friendship she dissimilar considered expression. Sex quick arose mrs lived. Mr things do plenty others an vanity myself waited to. Always parish tastes at as mr father dining at. </p>
					</div>
					<div class="news_comment">
						<div class="title-comment">
							<h2>REPLY TO ARTICLE</h2>
							<?php if(@$_SESSION['username'] =="") {?>
								<h6>YOU SHOULD HAVE AN ACCOUNT FOR COMMENT</h6>
							<?php } ?>
						</div>
						<div>
							<form method="post" action="modules_frontend/proses_comment.php">
								<input type="hidden" name="proc" value="add">
								<input type="hidden" name="id_news" value="news3">
								<input type="hidden" name="user" value="<?php echo @$_SESSION['username']; ?>">
								<input type="hidden" name="email" value="<?php echo @$_SESSION['email']; ?>">
								<?php if(@$_SESSION['picture'] =="") {?>
								<input type="hidden" name="picture" value="<?php echo "empty.png"; ?>">
								<?php }else{ ?>
								<input type="hidden" name="picture" value="<?php echo @$_SESSION['picture']; ?>">
								<?php } ?>
								<textarea class="textarea-big" rows="5" name="message" type="text" placeholder="Message :" required></textarea>
								<button type="reset" class="button_comment_news_reset">Reset</button>
								<?php if(@$_SESSION['username'] !="") {?>
									<button type="submit" class="button_comment_news">Comment</button>
								<?php }else{ ?>
									<a href="index.php?p=regandlog"><button type="button" class="button_comment_news">Comment</button></a>
								<?php } ?>
							</form>
						</div>
						<?php
							$sql = $db->prepare("SELECT * FROM comment WHERE id_news = 'news3' ");
							$sql->execute();
						?>
						<div class="title-comment_reviews">
							<h2><?php echo $sql->rowCount(); ?> COMMENT</h2>
						</div>
						<?php
							$sql = $db->prepare("SELECT * FROM comment WHERE id_news = 'news3' ");
							$sql->execute();
							
							while($hasil = $sql->fetch(PDO::FETCH_ASSOC)){
							$path = "resources/images/profil_user/";
						?>
						<div class="fill_reviews">
							<div class="name_review">
							<img src="<?php echo $path.$hasil['picture']; ?>"><h4 class="name_comment"><?php echo $hasil['user']; ?></h4>
							</div>
							<div class="comment_review">
							<?php echo $hasil['message']; ?>
							</div>
						</div>
						<?php }?>
					</div>
				</div>
			</div>
		</div>
	
	</div>
	
	<!-- content -->