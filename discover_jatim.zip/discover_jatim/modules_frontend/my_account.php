<?php include ("database.php");?>
<?php session_start();?>
<html>
<head>
	<title>IRZ STORE</title>
	<meta name="viewport" content="width=device-width, initial scale=1">
	<link rel="stylesheet" type="text/css" href="resources/css/style.css">
	<link rel="shortcut icon" href="resources/images/logo/irzstorelogo2.png">
</head>
<body>
	<!-- header -->
	<header class="large">
		<div class="top-menu">
			<div class="container">
				<div class="row">
					<div class="col-6">
						<li><a href="index.php?p=regandlog">LOGIN</a> or <a href="index.php?p=regandlog">REGISTER</a><span class="sep">|</span><a id="date"></a></li>
					</div>
					<div class="col-6">
						<li class="menu-right">
							<a href="wishlist.html">WISHLIST</a>
							<span class="sep">|</span>
							<a href="stores.html">STORE</a>
							<span class="sep">|</span>
								<?php if(@$_SESSION['username'] !=""){  ?>
								<?php
									$sql = $db->prepare ("SELECT username, email, password FROM regandlog WHERE username = '$_SESSION[username]'");
									$sql->execute();
									
									$hasil = $sql->fetch(PDO::FETCH_ASSOC)
								?>
								<a class="focus_account"><?php echo @$hasil['username'];?>
									<span class="profil_user">
										<div class="circle_profil">
											<img src="resources/images/profil_user/irsyad.jpg">
										</div>
										<div class="name_profil">
											<?php echo @$hasil['username']; ?>
										</div>
										<div class="button_logout">
											<form action="logout.php">
												<button type="text">LOGOUT</button>
											</form>
										</div>
									</span>
								</a>
								<?php }else{ ?>
									<a href="index.php?p=regandlog">MY ACCOUNT</a>
								<?php } ?>
						</li>
						
					</div>
				</div>
			</div>
		</div>
		
		<div class="top-menu2">
			<div class="container">
				<div class="row">
					<div class="col-3">
						<div class="logo">
							<img src="resources/images/logo/irzstorelogo.png" width="200px" height="35px">
						</div>
					</div>
					<div class="col-7">
						<nav class="nav">
							<ul>
								<li>
									<a href="#"><i class="active">HOME</i></a>
								</li>
								<li>
									<a href="product.html"><i>PRODUCT</i></a>
									<ul>
										<li class="image"><a href="#"><img src="resources/images/icon/cart_icon.png" width="60px" height="60px"></a></li>
										<li class="sili"><a href="#">SHOP VARIANT</a></li>
										<li><a href="#">GADGET</a></li>
										<li><a href="#">FASHION</a></li>
										<li><a href="#">SHOES</a></li>
										<li><a href="#">BRANDS</a></li>
										<li><a href="#">ACCESSORIES</a></li>
									</ul>
									<ul class="mar2">
										<li class="image"><a href="#"><img src="resources/images/icon/electronic_icon.png" width="60px" height="60px"></a></li>
										<li class="sili"><a href="#">ELECTRONIC</a></li>
										<li><a href="#">SMARTPHONE</a></li>
										<li><a href="#">CAMERA</a></li>
										<li><a href="#">LAPTOP</a></li>
										<li><a href="#">FLASHDISK</a></li>
										<li><a href="#">TV</a></li>
									</ul>
									<ul class="mar3">
										<li class="image"><a href="#"><img src="resources/images/icon/shirt_icon.png" width="60px" height="60px"></a></li>
										<li class="sili"><a href="#">CLOTHES</a></li>
										<li><a href="#">SHIRT</a></li>
										<li><a href="#">MEN</a></li>
										<li><a href="#">WOMEN</a></li>
										<li><a href="#">ACCESSORIES</a></li>
										<li><a href="#">SHOES</a></li>
									</ul>
									<ul class="mar4">
										<li class="image-big"><a href="#"><img src="resources/images/banner/CANON-EOS-700D_banner.png" width="236" height="170"></a></li>
									</ul>
								</li>
								<li>
									<a href="men.html"><i>MEN</i></a>
									<ul>
										<li class="image"><a href="#"><img src="resources/images/icon/watch.png" width="60px" height="60px"></a></li>
										<li class="sili"><a href="#">WATCHES</a></li>
										<li><a href="#">SMARTWATCH</a></li>
										<li><a href="#">WIRSTWATCH</a></li>
									</ul>
									<ul class="mar2">
										<li class="image"><a href="#"><img src="resources/images/icon/shoes.png" width="60px" height="60px"></a></li>
										<li class="sili"><a href="#">SHOES</a></li>
										<li><a href="#">SNEAKERS</a></li>
										<li><a href="#">RUNNING</a></li>
										<li><a href="#">BASKETBALL</a></li>
										<li><a href="#">PANTOFEL</a></li>
									</ul>
									<ul class="mar3">
										<li class="image-big"><a href="#"><img src="resources/images/banner/man_clothing_banner.png" width="236" height="170"></a></li>
									</ul>
								</li>
								<li>
									<a href="women.html"><i>WOMEN</i></a>
									<ul>
										<li class="image"><a href="#"><img src="resources/images/icon/Beauty_Saloon.png" width="60px" height="60px"></a></li>
										<li class="sili"><a href="#">BEAUTY</a></li>
										<li><a href="#">LIPSTICK</a></li>
										<li><a href="#">EYE LINER</a></li>
										<li><a href="#">CREAM</a></li>
										<li><a href="#">PERFUME</a></li>
									</ul>
									<ul class="mar2">
										<li class="image"><a href="#"><img src="resources/images/icon/high_heels.png" width="60px" height="60px"></a></li>
										<li class="sili"><a href="#">SHOES</a></li>
										<li><a href="#">HIGHHEELS</a></li>
										<li><a href="#">SNEAKERS</a></li>
										<li><a href="#">BOOTS</a></li>
										<li><a href="#">FLAT</a></li>
									</ul>
									<ul class="mar3">
										<li class="image-big"><a href="#"><img src="resources/images/banner/woman_clothing_banner.png" width="236" height="170"></a></li>
									</ul>
								</li>
								<li>
									<a href="blog.html"><i>BLOG</i></a>
								</li>
								<li>
									<a href="stores.html"><i>STORES</i></a>
								</li>
							</ul>
						</nav>
					</div>
					<div class="col-2">
						
						<form>
						<input class="ani" type="search" src="resources/images/icon/search_icon.png" placeholder="Search...">
						</form>
							<a href="cart.html">
								<img class="cart-icon" src="resources/images/icon/shoping_cart.png" width="30px" height="30px">
							</a>
						<span class="circle-cart">1</span>
					</div>
				</div>
			</div>
		</div>
	</header>
	<!-- header -->
	<!-- slider -->
		<div class="contain">
			<input type="radio" name="slide" class="radio-nav" id="nav-1" checked/>
			<input type="radio" name="slide" class="radio-nav" id="nav-2"/>
			<input type="radio" name="slide" class="radio-nav" id="nav-3"/>

			<ul class="slide">
				<li class="slide-1">
					<img src="resources/images/banner/banner-clothing.png"/>
					<div class="caption">CLOTHING</div>
				</li>
				<li class="slide-2">
					<img src="resources/images/banner/banner-tv-panasonic.png"/>
					<div class="caption">TV</div>
				</li>
				<li class="slide-3">
					<img src="resources/images/banner/banner-samsung-smartphone.png"/>
					<div class="caption">SMARTPHONE</div>
				</li>
			</ul>

			<div class="nav-arrow nav-next">
				<label class="nav-1" for="nav-1">></label>
				<label class="nav-2" for="nav-2">></label>
				<label class="nav-3" for="nav-3">></label>
			</div>
			<div class="nav-arrow nav-prev">
				<label class="nav-1" for="nav-1"><</label>
				<label class="nav-2" for="nav-2"><</label>
				<label class="nav-3" for="nav-3"><</label>
			</div>
		</div>
	<!-- slider -->
	<!-- content -->
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-12">
				<div class="title-content">
					<strong>BEST SELLERS</strong>
					<small class="small-title-content">MOST SOLD ITEM IN THE MARKET</small>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-3">
				<div class="item">
					<div class="item-image">
						<a href="macbook.html"><img src="resources/images/APPLE-MacBook-Pro-13-3-Zoll.png" width="263" width="196"></a>
					</div>
					<div class="item-info">
						<h3><a href="macbook.html">MACBOOK PRO 13"</a></h3><h3 class="button_cart"><a href="">&times;</a></h3>
						<span class="type"><a href="">COMPUTERS</a></span>
						<h3 class="price">Rp 13,175 K</h3><h5 class="wrong-price">Rp 13,500 K</h5>
					</div>
					<span class="sale">SALE!</span>
				</div>
			</div>
			<div class="col-3">
				<div class="item">
					<div class="item-image">
						<a href="cool_kids.html"><img src="resources/images/image-shirt2.png" width="263" width="196"></a>
					</div>
					<div class="item-info">
						<h3><a href="cool_kids.html">COOL KIDS CLUB</a></h3><h3 class="button_cart"><a href="">&times;</a></h3>
						<span class="type"><a href="">SHIRT</a></span>
						<h3 class="price">Rp 270 K</h3><h5 class="wrong-price">Rp 300 K</h5>
					</div>
					<span class="featured">FEATURED</span>
				</div>
			</div>
			<div class="col-3">
				<div class="item">
					<div class="item-image">
						<a href="canon.html"><img src="resources/images/CANON-EOS-700D-18-55mm-IS-STM-8.png" width="263" width="196"></a>
					</div>
					<div class="item-info">
						<h3><a href="canon.html">CANON EOS 600D</a></h3><h3 class="button_cart"><a href="">&times;</a></h3>
						<span class="type"><a href="">CAMERA</a></span>
						<h3 class="price">Rp 6,175 K</h3><h5 class="wrong-price">Rp 6,500 K</h5>
					</div>
					<span class="disc">5% OFF</span>
				</div>
			</div>
			<div class="col-3">
				<div class="item">
					<div class="item-image">
						<a href=""><img src="resources/images/SAMSUNGS5-UE55H6270.png" width="263" width="196"></a>
					</div>
					<div class="item-info">
						<h3><a href="">SAMSUNG GALAXY S5</a></h3><h3 class="button_cart"><a href="">&times;</a></h3>
						<span class="type"><a href="">SMARTPHONE</a></span>
						<h3 class="price">Rp 6,000 K</h3>
					</div>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-12">
				<div class="title-content">
					<strong>MOST VIEWED</strong>
					<small class="small-title-content">MOST VIEWER PRODUCT IN THE MARKET</small>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-3">
				<div class="item">
					<div class="item-image">
						<a href="cheap_monday.html"><img src="resources/images/image-shirt.png" width="263" width="196"></a>
					</div>
					<div class="item-info">
						<h3><a href="cheap_monday.html">CHEAP MONDAY</a></h3><h3 class="button_cart"><a href="">&times;</a></h3>
						<span class="type"><a href="">SHIRT</a></span>
						<h3 class="price">Rp 320 K</h3>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="item">
					<div class="item-image">
						<a href=""><img src="resources/images/image_glasses.png" width="263" width="196"></a>
					</div>
					<div class="item-info">
						<h3><a href="">GLASSES</a></h3><h3 class="button_cart"><a href="">&times;</a></h3>
						<span class="type"><a href="">ACCESSORIES</a></span>
						<h3 class="price">Rp 79 K</h3><h5 class="wrong-price">Rp 90 K</h5>
					</div>
					<span class="sale">SALE!</span>
				</div>
			</div>
			<div class="col-3">
				<div class="item">
					<div class="item-image">
						<a href=""><img src="resources/images/BEATS-Beats-by-Dr.png" width="263" width="196"></a>
					</div>
					<div class="item-info">
						<h3><a href="">BEATS BY DRE</a></h3><h3 class="button_cart"><a href="">&times;</a></h3>
						<span class="type"><a href="">ACCESSORIES</a></span>
						<h3 class="price">Rp 700 K</h3>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="item">
					<div class="item-image">
						<a href=""><img src="resources/images/asap_bag.png" width="263" width="196"></a>
					</div>
					<div class="item-info">
						<h3><a href="">ASAP BAG</a></h3><h3 class="button_cart"><a href="">&times;</a></h3>
						<span class="type"><a href="">BAGS</a></span>
						<h3 class="price">Rp 405 K</h3><h5 class="wrong-price">Rp 450 K</h5>
					</div>
					<span class="disc">10% OFF</span>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-12">
				<div class="title-content">
					<strong>MOST VIEWED</strong>
					<small class="small-title-content">MOST VIEWER PRODUCT IN THE MARKET</small>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-3">
				<div class="item">
					<div class="item-image">
						<a href=""><img src="resources/images/CANON-MG-6450-PIXMA.png" width="263" width="196"></a>
					</div>
					<div class="item-info">
						<h3><a href="">CANON PIXMA MG</a></h3><h3 class="button_cart"><a href="">&times;</a></h3>
						<span class="type"><a href="">PRINTERS</a></span>
						<h3 class="price">Rp 1500 K</h3><h5 class="wrong-price">Rp 2,000 K</h5>
					</div>
					<span class="featured">FEATURED</span>
				</div>
			</div>
			<div class="col-3">
				<div class="item">
					<div class="item-image">
						<a href=""><img src="resources/images/wd-my-passportu00ae-ultrau2122-1.png" width="263" width="196"></a>
					</div>
					<div class="item-info">
						<h3><a href="">WD MY PASSPORT</a></h3><h3 class="button_cart"><a href="">&times;</a></h3>
						<span class="type"><a href="">ACCESSORIES</a></span>
						<h3 class="price">Rp 1,200 K</h3>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="item">
					<div class="item-image">
						<a href=""><img src="resources/images/TOSHIBA-32L3443DG.png" width="263" width="196"></a>
					</div>
					<div class="item-info">
						<h3><a href="">TOSHIBA 32L3443DG</a></h3><h3 class="button_cart"><a href="">&times;</a></h3>
						<span class="type"><a href="">tv</a></span>
						<h3 class="price">Rp 2,400 K</h3>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="item">
					<div class="item-image">
						<a href=""><img src="resources/images/imageshoes.png" width="263" width="196"></a>
					</div>
					<div class="item-info">
						<h3><a href="">ONETWOS SHOES</a></h3><h3 class="button_cart"><a href="">&times;</a></h3>
						<span class="type"><a href="">SHOES</a></span>
						<h3 class="price">Rp 350 K</h3><h5 class="wrong-price">Rp 400 K</h5>
					</div>
					<span class="sale">SALE!</span>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-12">
				<div class="content-ship">
					<div class="content-ship-in">
						<div class="content-ship-in">
							<div class="content-ship-in-ok">
								<h1 class="title-ship">MARCH SALE</h1>
								<h5 class="title-ship">FREE SHIPING OVER RP 1,500K FOR INTERATIONAL ORDER</h5>
							</div>
							<span class="ship-circle">SHOP NOW</span>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-12">
				<div class="title-content">
					<strong>TOP BRAND</strong>
					<small class="small-title-content">MOST POPULAR BRANDS	</small>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-2">
				<div class="content-brand">
					<img src="resources/images/brand/bershka.png" width="144" height="60px">
				</div>
			</div>
			<div class="col-2">
				<div class="content-brand">
					<img src="resources/images/brand/canon.png" width="144" height="60px">
				</div>
			</div>
			<div class="col-2">				
				<div class="content-brand">
					<img src="resources/images/brand/dkny.png" width="144" height="60px">
				</div>
			</div>
			<div class="col-2">				
				<div class="content-brand">
					<img src="resources/images/brand/hm.png" width="144" height="60px">
				</div>
			</div>
			<div class="col-2">				
				<div class="content-brand">
					<img src="resources/images/brand/htc.png" width="144" height="60px">
				</div>
			</div>
			<div class="col-2">				
				<div class="content-brand">
					<img src="resources/images/brand/intel.png" width="144" height="60px">
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-2">
				<div class="content-brand-down">
					<img src="resources/images/brand/mango.png" width="144" height="60px">
				</div>
			</div>
			<div class="col-2">
				<div class="content-brand-down">
					<img src="resources/images/brand/microsoft.png" width="144" height="60px">
				</div>
			</div>
			<div class="col-2">				
				<div class="content-brand-down">
					<img src="resources/images/brand/nikon.png" width="144" height="60px">
				</div>
			</div>
			<div class="col-2">				
				<div class="content-brand-down">
					<img src="resources/images/brand/selected.png" width="144" height="60px">
				</div>
			</div>
			<div class="col-2">				
				<div class="content-brand-down">
					<img src="resources/images/brand/toshiba.png" width="144" height="60px">
				</div>
			</div>
			<div class="col-2">				
				<div class="content-brand-down">
					<img src="resources/images/brand/zara.png" width="144" height="60px">
				</div>
			</div>
		</div>
	</div>
	<!-- content -->
	<!-- footer -->
	<footer>
		<div class="container">
			<div class="row">
				<div class="col-2">
					<nav class="nav2">
						<li class="title-footer">WHAT'S HOT</li>
						<li><a href="">DISCOUNT VOUCHER</a></li>
						<li><a href="index.html">TOP RATED</a></li>
						<li><a href="index.html">BEST SELLERS</a></li>
						<li><a href="index.html">VIEWERS</a></li>
					</nav>				
				</div>
				<div class="col-2">
					<nav class="nav2">
						<li class="title-footer">BRANDS</li>
						<li><a href="index.html">SAMSUNG</a></li>
						<li><a href="index.html">ZARA</a></li>
						<li><a href="index.html">NIKE</a></li>
						<li><a href="index.html">ADIDAS</a></li>
					</nav>	
				</div>
				<div class="col-2">
					<nav class="nav2">
						<li class="title-footer">MEN SHOP</li>
						<li><a href="men.html">TOPS</a></li>
						<li><a href="men.html">BOTTOM</a></li>
						<li><a href="men.html">ACCESSORIES</a></li>
						<li><a href="men.html">SHOES</a></li>
					</nav>	
				</div>
				<div class="col-2">
					<nav class="nav2">
						<li class="title-footer">WOMEN SHOP</li>
						<li><a href="women.html">JEANS</a></li>
						<li><a href="women.html">DRESSED</a></li>
						<li><a href="women.html">ACCESSORIES</a></li>
						<li><a href="women.html">SHOES</a></li>
					</nav>	
				</div>
				<div class="col-2">
					<nav class="nav2">
						<li class="title-footer">HELP</li>
						<li><a href="">F.A.Q.</a></li>
						<li><a href="">CONTACT US</a></li>
						<li><a href="">SHIPPING</a></li>
						<li><a href="">PRIVACY POLICY</a></li>
					</nav>	
				</div>
				<div class="col-2">
					<nav class="nav2">
						<li class="title-footer">SOCIAL</li>
						<img src="resources/images/icon/facebook.png">
						<img src="resources/images/icon/instagram.png">
						<img src="resources/images/icon/twitter.png">
						<img src="resources/images/icon/youtube.png">
					</nav>	
				</div>
			</div>
			<div class="row">
				<div class="col-12">
					<div class="trash-footer">
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-6">
					<div class="bottom-footer">
					Copyright &copy; 2017 - IRZ STORE
					<li class="bottom-footer2"><a href="">Privacy & Cookies</a><span class="sep">|</span><a href="">Term & Condition</a><span class="sep">|</span><a href="">Accessibility</a><span class="sep">|</span><a href="">Store</a><span class="sep">|</span><a href="">Directory</a><span class="sep">|</span><a href="">About Us</a></li>
					</div>
					
				</div>
				<div class="col-6">
					<div class="shipping_logo">
						<img src="resources/images/transfer_shipping/dhl.png" width="73" height="10">
						<img src="resources/images/transfer_shipping/j&t.png" width="50" height="30">
						<img src="resources/images/transfer_shipping/jne.png" width="60" height="20">
						<img src="resources/images/transfer_shipping/mastercard.png" width="28" height="17">
						<img src="resources/images/transfer_shipping/posindonesia.png" width="35" height="24">
						<img src="resources/images/transfer_shipping/tiki.png" width="40" height="35">
						<img src="resources/images/transfer_shipping/visa.png" width="38" height="11">
					</div>
				</div>
			</div>
		</div>
	</footer>
	<a href="#" class="ScrollToTop">TOP</a>
	<!-- footer -->
	
	<script src="resources/js/jquery.min.js"></script>
	<script>
$(document).on("scroll" ,function(){
		if($(document).scrollTop()>10){
			$("header").removeClass("large").addClass("small");
		}else{
			$("header").removeClass("small").addClass("large")
		}	
	});
	
$(document).ready(function(){
	$(window).scroll(function(){
		if($(this).scrollTop() > 50){
			$('.scrollToTop').fadeIn();
		}else{
			$('.scrollToTop').fadeOut();
		}
		});
		
		$('.scrollToTop').click(function(){
			$('html, body').animate({scrollTop : 0}, 800);
			return false;
		});
	});
	
var months = ['January', 'February', 'March', 'April', 'May', 'Juny', 'July', 'August', 'September', 'October', 'November', 'December'];
var myDays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
var date = new Date();
var day = date.getDate();
var month = date.getMonth();
var thisDay = date.getDay(),
    thisDay = myDays[thisDay];
var yy = date.getYear();
var year = (yy < 1000) ? yy + 1900 : yy;
document.getElementById("date").innerHTML = (thisDay + ', ' + day + ' ' + months[month] + ' ' + year);
	</script>
</body>
</html>