
	<!-- content -->
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-12">
				<div class="title-content">
					<strong>NEWS</strong>
					<small class="small-title-content">UPDATED NEWS EVERY DAYS</small>
				</div>
			</div>
		</div>

		<?php
			$sql = $db->prepare("SELECT * FROM news");
			$sql->execute();
			$path = "resources/images/news/";
			
			while($hasil = $sql->fetch(PDO::FETCH_ASSOC)){
		?>
		<div class="row">
			<div class="col-12">
				<div class="news">
					<div class="news-image">
						<img src="<?php echo $path.$hasil['picture']; ?>">
						<span class="tooltip"><a href="index.php?p=news_detail&id=<?php echo base64_encode($hasil['id_news']); ?>"><b>CONTINUE READING</b></a></span>
					</div>
					<div class="news-info">
						<h1><a href="index.php?p=news_detail&id=<?php echo base64_encode($hasil['id_news']); ?>"><?php echo $hasil['title']; ?></a></h1>
						<div class="time_news_detail">&#9200; <i style="top:-2px; position:relative;"><?php echo date("H:m:s", strtotime($hasil['created_at'])); ?></i></div>
						<p class="content-info" style="margin-bottom:10px; text-align:justify;"><?php echo nl2br(substr($hasil['description'], 0, 468)); ?>…</p>
						<p class="content-info"><a href="index.php?p=news_detail&id=<?php echo base64_encode($hasil['id_news']); ?>">Continue Reading &raquo;</a>
						</p>
					</div>
				</div>
			</div>
		</div>
		<?php } ?>
		
		<div class="row">
			<div class="col-12">
				<div class="pagination">
					<a href="#">&laquo;</a>
					<a href="#" class="active">1</a>
					<a href="index.php?p=blog2">2</a>
					<a href="#">3</a>
					<a href="index.php?p=blog2">&raquo;</a>
				</div>
			</div>
		</div>
	
	</div>
	
	<!-- content -->