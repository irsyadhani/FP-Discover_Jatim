<?php 
	if(@$_GET['idcomment'] !=""){
		$idNews = base64_decode(@$_GET['idcomment']);
	}elseif(@$_GET['idreview'] !=""){
		$idReview = base64_decode(@$_GET['idreview']);
	}
?>
	<!-- content -->
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-6">
				<div class="title-content">
					<strong>LOGIN</strong>
					<small class="small-title-content">MANAGE YOUR ACCOUNT AND SEE YOUR ORDERS</small>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-6">
				<div class="stores_letter">
					<form method="post" 
					<?php if(@$_GET['idcomment'] !="") {?>
					action="modules_frontend/proses_login.php?idcomment=<?php echo base64_encode($idNews); ?>"
					<?php }elseif(@$_GET['idreview'] !=""){ ?>
					action="modules_frontend/proses_login.php?idreview=<?php echo base64_encode($idReview); ?>"
					<?php }elseif(@$_GET['id'] =="product"){ ?>
					action="modules_frontend/proses_login.php&id=product"
					<?php }else{ ?>
					action="modules_frontend/proses_login.php"
					<?php } ?>
					>
						<input class="input-1-full" type="text" name="username" placeholder="Username*" required>
						<input class="input-1-full" type="password" name="password" placeholder="Password*" required>
						<button type="submit" class="button_login">Login</button>
						<button type="reset" class="button_reset_login">Reset</button>
					</form>
				</div>
			</div>
			<div class="col-6">
				<div class="stores_letter">
					<form method="post" 
					<?php if(@$_GET['idcomment'] !="") {?>
					action="modules_frontend/proses_register.php?idcomment=<?php echo base64_encode($idNews); ?>" 
					<?php }elseif(@$_GET['idreview'] !=""){ ?>
					action="modules_frontend/proses_register.php?idreview=<?php echo base64_encode($idReview);?>" 
					<?php }else{ ?>
					action="modules_frontend/proses_register.php" 
					<?php } ?>
					enctype="multipart/form-data">
						<input type="hidden" name="proc" value="add_register">
						<input class="input-1-full" type="text" name="username" placeholder="Username*" required>
						<input class="input-1-full" type="email" name="email" placeholder="E-mail address*" required>
						<input class="input-1-full" type="password" name="password" placeholder="Password*" required>
						<input type="file" name="picture" style="position:absolute; margin-left:90px; margin-top:22px; color:#ff9800;" id="upload_user">
							<label for="upload_user" class="user_upload">
							Choose Your Image Profile
							</label>
						<button type="submit" class="button_login" style="margin-top:60px;">Register</button>
						<button type="reset" class="button_reset_login" style="margin-top:60px;">Reset</button>
					</form>
				</div>
			</div>
		</div>
				
	</div>
	
	<!-- content -->