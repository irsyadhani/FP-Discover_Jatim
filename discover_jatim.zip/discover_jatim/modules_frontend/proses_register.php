<?php
	if(@$_GET['idcomment'] !=""){
		$idNews = base64_decode(@$_GET['idcomment']);
	}elseif(@$_GET['idreview'] !=""){
		$idReview = base64_decode(@$_GET['idreview']);
	}
	session_start();
	include("../database.php");
	
		$v_proc = $_REQUEST['proc'];
		
		switch($v_proc){
			case "add_register":
			
			$v_picture = $_FILES['picture']['name'];
			$tmp = $_FILES['picture']['tmp_name'];
			$type = $_FILES['picture']['type'] = ("png" && "jpeg" && "jpg" && "gif");
			move_uploaded_file($tmp, "../resources/images/profil_user/".$v_picture);
			
			$v_username = $_POST['username'];
			$v_email = $_POST['email'];
			$v_password = $_POST['password'];
			
			$sql = $db->prepare("INSERT INTO user(username, email, password, picture) VALUES (:usernameParam, :emailParam, :passwordParam, :pictureParam)");
			
			$sql->bindParam(':usernameParam', $v_username);
			$sql->bindParam(':emailParam', $v_email);
			$sql->bindParam(':passwordParam', $v_password);
			$sql->bindParam(':pictureParam', $v_picture);
						
			$sql->execute();
			
			$sql = $db->prepare("SELECT * FROM user WHERE username='$v_username' AND email='$v_email' AND password='$v_password'");
			$sql->execute();
			$cek = $sql->rowCount();
			
			if($cek > 0){
				$_SESSION['username'] = $v_username;
				if($_FILES['picture']['name'] != '') $_SESSION['picture'] = $v_picture;
					
				if(@$_GET['idcomment'] !=""){
					echo "
					<script>
						alert('Login Succes');
						window.location.href='../index.php?p=news_detail&id=".base64_encode($idNews)."';
					</script>
					";
				}elseif(@$_GET['idreview'] !=""){
					echo "
					<script>
						alert('Login Succes');
						window.location.href='../index.php?p=product_detail&id=".base64_encode($idReview)."';
					</script>
					";
				// }elseif(@$_GET['p'] =="product"){
					// echo "
					// <script>
						// alert('Login Succes');
						// window.location.href='../index.php?p=product';
					// </script>
					// ";
				}else{
					echo "
					<script>
						alert('Login Succes');
						window.location.href='../index.php';
					</script>
					";
				}			
			}
			
			break;
			
			case "edit":
			
			$v_id_user = $_POST['id_user'];
			$v_picture = $_FILES['picture']['name'];
			$tmp = $_FILES['picture']['tmp_name'];
			$type = $_FILES['picture']['type'] = ("png" && "jpeg" && "jpg" && "gif");
			move_uploaded_file($tmp, "../resources/images/profil_user/".$v_picture);
			
			$sql = $db->prepare("UPDATE user SET picture = :pictureParam WHERE id_user = :id_user");
			
			$sql->bindParam(':id_user', $v_id_user);
			$sql->bindParam(':pictureParam', $v_picture);
						
			$sql->execute();
					
			if($_POST['id_user'] != ""){
				if($_GET['p'] =="product"){
					echo"
						<script>
							alert('Change Succes');
							window.location.href='index.php?p=product';
						</script>
					";
				}elseif($_GET['p'] =="men"){
					echo"
						<script>
							alert('Change Succes');
							window.location.href='index.php?p=men';
						</script>
					";
				}elseif($_GET['p'] =="women"){
					echo"
						<script>
							alert('Change Succes');
							window.location.href='index.php?p=women';
						</script>
					";
				}elseif($_GET['p'] =="blog"){
					echo"
						<script>
							alert('Change Succes');
							window.location.href='index.php?p=blog';
						</script>
					";
				}elseif($_GET['p'] =="stores"){
					echo"
						<script>
							alert('Change Succes');
							window.location.href='index.php?p=stores';
						</script>
					";
				}else{
					echo"
						<script>
							alert('Change Succes');
							window.location.href='index.php?p';
						</script>
					";
				}
				
				
			}else{
				echo"
					<script>
						alert('Change Failed');
						window.location.href='index.php?p';
					</script>
				";
			}
			
			break;
		}
		