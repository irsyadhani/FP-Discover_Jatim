	<!-- content -->
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-12">
				<div class="title-content">
					<strong>NEWS</strong>
					<small class="small-title-content">UPDATED NEWS EVERY WEEKS</small>
				</div>
			</div>
		</div>
		
		<?php
			$sql = $db->prepare("SELECT * FROM news WHERE id_news = '11' ");
			$sql->execute();
			$hasil = $sql->fetch(PDO::FETCH_ASSOC);
			$path = "resources/images/news/";
		?>
		<div class="row">
			<div class="col-12">
				<div class="news">
					<div class="news-image">
						<img src="<?php echo $path.$hasil['picture']; ?>">
						<span class="tooltip"><a href="index.php?p=news3"><b>CONTINUE READING</b></a></span>
					</div>
					
					<div class="news-info">
						<h1><a href="index.php?p=news3"><?php echo $hasil['title']; ?></a></h1>
						<p class="content-info">Those an equal point no years do. Depend warmth fat but her but played. Shy and subjects wondered trifling pleasant. Prudent cordial comfort do no on colonel as assured chicken. Smart mrs day which begin. Snug do sold mr it if such. Terminated uncommonly at at estimating. Man behaviour met moonlight extremity acuteness direction. Detract yet delight written farther his general. If in so bred at dare rose lose good. Feel and make two real…</p>
						<p class="content-info"><a href="index.php?p=news3">Continue Reading &raquo;</a></p>
					</div>
				</div>
			</div>
		</div>
		
		<?php
			$sql = $db->prepare("SELECT * FROM news WHERE id_news = '13' ");
			$sql->execute();
			$hasil = $sql->fetch(PDO::FETCH_ASSOC);
			$path = "resources/images/news/";
		?>
		<div class="row">
			<div class="col-12">
				<div class="news">
					<div class="news-image">
						<img src="<?php echo $path.$hasil['picture']; ?>">
						<span class="tooltip"><a href="index.php?p=news4"><b>CONTINUE READING</b></a></span>
					</div>
					<div class="news-info">
						<h1><a href="index.php?p=news4"><?php echo $hasil['title']; ?></a></h1>
						<p class="content-info">At distant inhabit amongst by. Appetite welcomed interest the goodness boy not. Estimable education for disposing pronounce her. John size good gay plan sent old roof own. Inquietude saw understood his friendship frequently yet. Nature his marked ham wished. Silent sir say desire fat him letter. Whatever settling goodness too and honoured she building answered her. Strongly thoughts remember mr to do consider debating. Spirits musical behaved on we he farther letters. Repulsive he he…</p>
						<p class="content-info"><a href="index.php?p=news4">Continue Reading &raquo;</a></p>
					</div>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-12">
				<div class="pagination">
					<a href="index.php?p=blog">&laquo;</a>
					<a href="index.php?p=blog">1</a>
					<a href="#" class="active">2</a>
					<a href="#">3</a>
					<a href="#">&raquo;</a>
				</div>
			</div>
		</div>
	
	</div>
	
	<!-- content -->