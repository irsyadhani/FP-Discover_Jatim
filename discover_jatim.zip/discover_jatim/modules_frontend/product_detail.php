<?php
	if(@$_GET['id'] !=""){
		$idProduct = base64_decode(@$_GET['id']);
		$sql = $db->prepare("SELECT *, A.name AS nameproduct, B.name AS namesort FROM product AS A LEFT JOIN sort AS B ON(A.id_sort = B.id_sort) WHERE id_product = :id_product");
		$sql->bindParam(':id_product', $idProduct);
		$sql->execute();
		$hasil = $sql->fetch(PDO::FETCH_ASSOC);
		$path = "resources/images/product/detail/";
		$query_rating = $db->prepare("SELECT AVG(rating) FROM product_rating WHERE id_product = '$idProduct'");
		$query_rating->execute();
		list($rating) = $query_rating->fetch(PDO::FETCH_NUM);
		$rating = ceil($rating);
	}
	?>
<!-- content -->
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		
		<div class="product_detail">
			<div class="row">
				<div class="col-6">
							
						<?php if(@$hasil['discount'] !=""){?>
						<div class="disc_detail"><?php echo $hasil['discount']; ?></div>
						<?php }elseif(@$hasil['product_status'] !=""){?>
						<div class="sale_detail">SALE!</div>
						<?php } ?>
						<div class="contain2">
							<input type="radio" name="slide2" class="radio-nav2" id="nav-12" checked/>
							<input type="radio" name="slide2" class="radio-nav2" id="nav-22"/>
							<input type="radio" name="slide2" class="radio-nav2" id="nav-32"/>
							
							<ul class="slide2">
								<li class="slide-12">
									<div class="product">
									<img onclick="modalImages('myImg')" id="myImg" src="<?php echo $path.$hasil['picture1']; ?>" width="100%"/>
									</div>
								</li>
								<li class="slide-22">
									<div class="product">
									<img onclick="modalImages('myImg2')" id="myImg2" src="<?php echo $path.$hasil['picture2']; ?>" width="100%"/>
									</div>
								</li>
								<li class="slide-32">
								<div class="product">
									<img onclick="modalImages('myImg3')" id="myImg3" src="<?php echo $path.$hasil['picture3']; ?>" width="100%"/>
									</div>
								</li>
								<div id="myModal" class="modal">
								  <span class="close">&times;</span>
								  <img class="modal-content" id="img01">
								</div>
							</ul>
							<div class="nav-arrow2 nav-next2">
								<label class="nav-12" for="nav-12">></label>
								<label class="nav-22" for="nav-22">></label>
								<label class="nav-32" for="nav-32">></label>
							</div>
							<div class="nav-arrow2 nav-prev2">
								<label class="nav-12" for="nav-12"><</label>
								<label class="nav-22" for="nav-22"><</label>
								<label class="nav-32" for="nav-32"><</label>
							</div>
						</div>
					</div>
				<div class="col-6">
					<div class="product_info">
						<strong><?php echo $hasil['nameproduct']; ?></strong>
						<small class="small-title-content"><a href=""><?php echo $hasil['namesort']; ?></a></small>
						<span class="rating">
							<?php
								for($i = 5; $i > 0; $i--){
							?>
							<input type="checkbox" class="rating-input" <?php if($i <= $rating) echo "checked"; ?> id="rating-input-1-<?php echo $i; ?>" value="<?php echo $i; ?>" name="rating" required/>
							<label for="rating-input-1-<?php echo $i; ?>" class="rating-star"></label>
							<?php } ?>
						</span>
						<span class="result_rating"><?php echo $rating; ?></span>
					</div>
					<div class="description">
						<p><?php echo nl2br($hasil['description']); ?></p>
					</div>
					<div class="price_detail">
						<p><h1><?php echo $hasil['price']; ?></h1></p>
					</div>
					<div class="form_add_cart">
						<form>
						<input type="number" min="1" value="1">
						<button type="submit"><b>+</b> ADD TO CART</button>
						</form>
					</div>
					<div class="button_wishlist">
						<form method="post" action="modules_frontend/proses_wishlist">
							<input type="hidden" name="proc" value="add">
							<input type="hidden" value="<?php echo $_SESSION['username']; ?>">
							<input type="hidden" value="<?php echo $hasil['nameproduct']; ?>">
							<input type="hidden" value="<?php echo $hasil['price']; ?>">
							<input type="hidden" value="<?php echo $hasil['picture']; ?>">
							<button type="submit"><b>&#9825;</b> Add To Wishlist</button>
						<form>
					</div>
					<div class="stock">
						Stock : <a class="stock_a"><?php echo $hasil['stock']; ?></a>
					</div>
				</div>
			</div>
		
		
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-12">
				<div class="news_comment">
					<div class="title-comment">
						<h2>ADD A REVIEW</h2>
						<?php if(@$_SESSION['username'] =="") {?>
							<h6>YOU SHOULD HAVE AN ACCOUNT OR LOGIN FOR REVIEW</h6>
						<?php } ?>
					</div>
					<div>
						<?php if(@$_SESSION['username'] !="") {?>
						<form method="post" action="modules_frontend/proses_revandrat.php">
						<input type="hidden" name="proc" value="add">
						<span class="rating">
							<?php
								for($i = 5; $i > 0; $i--){
							?>
							<input type="checkbox" class="rating-input" <?php if($i <= $rating) echo "checked"; ?> id="rating-input-1-<?php echo $i; ?>" value="<?php echo $i; ?>" name="rating" required onclick="javascript: window.location.href='modules_frontend/proses_revandrat.php?proc=add_rating&id_product=<?php echo $idProduct; ?>&rating=<?php echo $i; ?>&username=<?php echo $_SESSION['username']; ?>'; " />
							<label for="rating-input-1-<?php echo $i; ?>" class="rating-star"></label>
							<?php } ?>
						</span>
						<span style="color:#ff9800;"><?php echo $rating; ?></span>
						<span class="notif_rating"> <-----Please select rating between 1 until 5</span>
						</form>
						<?php } ?>
						<form method="post" action="modules_frontend/proses_revandrat.php">
						<input type="hidden" name="proc" value="add">
						
						<textarea class="textarea-big" type="text" rows="8" name="message" placeholder="Your Review :" required></textarea>
						<input type="hidden" name="id_product" value="<?php echo $idProduct ?>" required>
						<input type="hidden" name="user" value="<?php echo $_SESSION['username']; ?>" required>
						<input type="hidden" name="email" value="<?php echo $_SESSION['email']; ?>" required>
						<?php if(@$_SESSION['picture'] =="") {?>
						<input type="hidden" name="picture" value="<?php echo "empty.png"; ?>">
						<?php }else{ ?>
						<input type="hidden" name="picture" value="<?php echo @$_SESSION['picture']; ?>">
						<?php } ?>
						<button type="reset" class="button_comment_product_reset">Reset</button>
						<?php if(@$_SESSION['username'] !="") {?>
						<button type="submit" class="button_comment_product">Submit</button>
						<?php }else{ ?>
						<a href="index.php?p=regandlog&idreview=<?php echo base64_encode($idProduct) ?>"><button type="button" class="button_comment_product">Submit</button></a>
						<?php } ?>
						</form>
					</div>
					<div class="title-comment_reviews">
						<?php
							$sql = $db->prepare("SELECT id_product FROM review WHERE id_product = '$idProduct'");
							$sql->execute();
						?>
						<h2><?php echo $sql->rowCount();?> REVIEWS FOR <?php echo $hasil['nameproduct']; ?></h2>
					</div>
					<?php
						$sql = $db->prepare("SELECT * FROM review WHERE id_product = '$idProduct'");
						$sql->execute();
						while($hasil = $sql->fetch(PDO::FETCH_ASSOC)){
						$path = "resources/images/profil_user/";
					?>
					<div class="fill_reviews">
						<div class="name_review">
						<img src="<?php echo $path.@$hasil['picture']; ?>">
						<h4 class="name_comment"><?php echo @$hasil['user']; ?></h4>
						</div>
						<div class="comment_review">
						<?php echo nl2br($hasil['message']); ?>
						<div class="time_message">
							&#9200; <i><?php echo date("d/M/Y", strtotime($hasil['created_at']))?></i>
						</div>
						</div>
					</div>
					<?php } ?>
					<!--div class="fill_reviews">
						<span class="rating_name">
							<input type="radio" class="rating-input" id="rating-input-1-5" name="rating-input-1" />
							<label for="rating-input-1-5" class="rating-star"></label>
							<input type="radio" class="rating-input" id="rating-input-1-4" name="rating-input-1" />
							<label for="rating-input-1-4" class="rating-star"></label>
							<input type="radio" class="rating-input" id="rating-input-1-3" name="rating-input-1" />
							<label for="rating-input-1-3" class="rating-star"></label>
							<input type="radio" class="rating-input" id="rating-input-1-2" name="rating-input-1" />
							<label for="rating-input-1-2" class="rating-star"></label>
							<input type="radio" class="rating-input" id="rating-input-1-1" name="rating-input-1" />
							<label for="rating-input-1-1" class="rating-star"></label>
						</span>
						<div class="name_review">
						<img src="resources/images/1020_2.png"><h4 class="name_comment">Angelina</h4>
						</div>
						<div class="comment_review">
						This was great!
						</div>
					</div-->
				</div>
			</div>
		</div>
	</div>
	</div>
	
	<!-- content -->