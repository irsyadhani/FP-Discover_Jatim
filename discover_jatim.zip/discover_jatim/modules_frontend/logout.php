<?php
	session_start();
	unset($_SESSION['username']);
	unset($_SESSION['email']);
	unset($_SESSION['picture']);

	echo"
		<script>
		window.location.href='../index.php';
		</script>
		";
?>