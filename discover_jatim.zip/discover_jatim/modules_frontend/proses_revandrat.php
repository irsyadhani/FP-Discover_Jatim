<?php
	include('../database.php');
		
	$v_proc = $_REQUEST['proc'];
	
	switch($v_proc){
		case "add":
			$v_id_product = $_POST['id_product'];
			$v_message = $_POST['message'];
			$v_email = $_POST['email'];
			$v_user = $_POST['user'];
			$v_picture = $_POST['picture'];
					
			$sql = $db->prepare("INSERT INTO review(id_product, user, email, message, picture) VALUES(:id_productParam, :userParam, :emailParam, :messageParam, :pictureParam)");
			
			$sql->bindParam(':id_productParam', $v_id_product);
			$sql->bindParam(':userParam', $v_user);
			$sql->bindParam(':emailParam', $v_email);
			$sql->bindParam(':messageParam', $v_message);
			$sql->bindParam(':pictureParam', $v_picture);
			
			$sql->execute();
			
			echo"
				<script>
					window.location.href='../index.php?p=product_detail&id=".base64_encode($v_id_product)."';
				</script>
			";
		break;
		
		case "add_rating":
			$v_id_product = $_GET['id_product'];
			$v_rating = $_GET['rating'];
			$v_username = $_GET['username'];
			
			$sql = $db->prepare("INSERT INTO product_rating(id_product, rating, username) VALUES(:id_productParam, :ratingParam, :usernameParam)");
			
			$sql->bindParam(':id_productParam', $v_id_product);
			$sql->bindParam(':ratingParam', $v_rating);
			$sql->bindParam(':usernameParam', $v_username);
			
			$sql->execute();
			
			 echo"
				<script>
					window.location.href='../index.php?p=product_detail&id=".base64_encode($v_id_product) ."';
				</script>
			 ";
		break;
	}