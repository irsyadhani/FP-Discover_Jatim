
	<!-- content -->
	<div class="container">
	<?php if(@$_GET['id_category'] != "") {?>
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
	<?php }elseif(@$_GET['id_sort'] != ""){ ?>
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
	<?php }elseif(@$_GET['p'] == "product"){ ?>
		<div class="row">
			<div class="col-4">
				<div class="banner-up">
					<img src="resources/images/banner/bohemian.jpg">
					<span class="tooltip"><a href=""><b>SHOP NOW</b></a></span>
				</div>
				<div class="banner-up2">
					<img src="resources/images/banner/high_heels.jpg">
					<span class="tooltip"><a href=""><b>SHOP NOW</b></a></span>
				</div>
			</div>
			<div class="col-4">
				<div class="banner-center">
					<img src="resources/images/banner/electronic.jpg">
					<span class="tooltip"><a href=""><b>SHOP NOW</b></a></span>
				</div>
			</div>
			<div class="col-4">
				<div class="banner-up">
					<img src="resources/images/banner/watch.jpg">
					<span class="tooltip"><a href=""><b>SHOP NOW</b></a></span>
				</div>
				<div class="banner-up2">
					<img src="resources/images/banner/sneakers.jpg">
					<span class="tooltip"><a href=""><b>SHOP NOW</b></a></span>
				</div>
			</div>
		</div>
	<?php } ?>
		
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-12">
				<div class="title-content">
					<strong>PRODUCT	</strong>
					<small class="small-title-content">CHECK IT OUT NOW</small>
				</div>
			</div>
		</div>
		
		<div class="row">
			<?php
				if(@$_GET['id_category'] != ""){
					$id_category = @$_GET['id_category'];
					$sql = $db->prepare("SELECT *, A.name AS nameproduct, B.name AS namesort FROM product AS A LEFT JOIN sort AS B ON(A.id_sort = B.id_sort) WHERE A.id_category = '$id_category'");
					
					$sql->execute();
				}elseif(@$_GET['id_sort'] != ""){
					$id_sort = @$_GET['id_sort'];
					$sql = $db->prepare("SELECT *, A.name AS nameproduct, B.name AS namesort FROM product AS A LEFT JOIN sort AS B ON(A.id_sort = B.id_sort) WHERE A.id_sort = '$id_sort'");
					
					$sql->execute();
				}elseif(@$_GET['p'] == "product"){
					$sql = $db->prepare("SELECT *, A.name AS nameproduct, B.name AS namesort FROM product AS A LEFT JOIN sort AS B ON(A.id_sort = B.id_sort)");
					
					$sql->execute();
				}
				
				while($hasil = $sql->fetch(PDO::FETCH_ASSOC)){
				$path = "resources/images/product/";
			?>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href="index.php?p=product_detail&id=<?php echo base64_encode($hasil['id_product']); ?>"><img src="<?php echo $path.@$hasil['picture']; ?>" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="index.php?p=product_detail&id=<?php echo base64_encode($hasil['id_product']); ?>"><?php echo @$hasil['nameproduct']; ?></a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href=""><?php echo @$hasil['namesort']; ?></a></span>
							<h3 class="price"><?php echo @$hasil['price']; ?></h3>
						</div>
						
						<?php 
							if($hasil['discount'] != ''){
								echo '<span class="disc">'.@$hasil['discount'].'</span>';
							}elseif($hasil['product_status'] == 'new'){
								echo '<span class="sale">SALE!</span>';
							}
						?>
					</div>
				</div>
			</div>
			<?php } ?>
		</div>
		
		
		
		<div class="row">
			<div class="col-12">
				<div class="pagination">
					<a href="#">&laquo;</a>
					<a href="#" class="active">1</a>
					<a href="index.php?p=product2">2</a>
					<a href="#">3</a>
					<a href="index.php?p=product2.html">&raquo;</a>
				</div>
			</div>
		</div>
	
	</div>
	
	<!-- content -->