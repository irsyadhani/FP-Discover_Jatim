<!-- content -->
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-12">
				<div class="title-content">
					<strong>PRODUCT	</strong>
					<small class="small-title-content">CHECK IT OUT NOW</small>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/bobble.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">BOBBLE BENIE</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">BOBBLE</a></span>
							<h3 class="price">Rp 110,000</h3>
						</div>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/festival.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">FESTIVAL STONE</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">RING</a></span>
							<h3 class="price">Rp 180,000</h3>
						</div>
						<span class="sale">SALE!</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/butterfly.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">BUTTERFLY</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">EARRING</a></span>
							<h3 class="price">Rp 120,000</h3>
						</div>
						<span class="sale">SALE!</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/backpacker.png" width="263" height="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">BACKPACKER GREY</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">BACKPACKER</a></span>
							<h3 class="price">Rp 294,000</h3>
						</div>
						<span class="disc">30% OFF</span>
					</div>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/skull.png" width="263" height="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">SKULL RING</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">RING</a></span>
							<h3 class="price">Rp 365,000</h3>
						</div>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/lylescott.png" width="263" height="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">LYLESCOTT</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">BAGS</a></span>
							<h3 class="price">Rp 255,000</h3>
						</div>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/ACER-Aspire-E5.png"></a>
						</div>
						<div class="item-info">
							<h3><a href="">ACER ASPIRE E5-571</a></h3>
							<h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">RING</a></span>
							<h3 class="price">Rp 8,521,000</h3>
						</div>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/APPLE-iPhone-6-16-GB-spacegrau-290x200.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">IPHONE 6 16 GB</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">RING</a></span>
							<h3 class="price">Rp 9,900,000</h3>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/ring_tiger.jpg" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">BILL SKINNER TIGER </a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">RING</a></span>
							<h3 class="price">Rp 800,000</h3>
						</div>
						<span class="sale">SALE!</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/image1xxl-119-290x370.jpg" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">BELFAST ROSE GOLD</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">JACKET</a></span>
							<h3 class="price">Rp 2,900,000</h3>
						</div>
						<span class="featured">FEATURED</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/rayban_classic.jpg" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">RAYBAN CLASSIC</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">BACKPACKER</a></span>
							<h3 class="price">Rp 210,000</h3>
						</div>
						<span class="disc">30% OFF</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/image1xxl-111-290x370.jpg" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">LACE COLLAR</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">RING</a></span>
							<h3 class="price">Rp 278,000</h3>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/image1xxl17-290x370.jpg" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">AQUA WRAP STONE </a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">SHIRT</a></span>
							<h3 class="price">Rp 558,000</h3>
						</div>
						<span class="featured">FEATURED</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/image1xxl-112-290x370.jpg" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">TRIANGLE NECKLACE</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">SHIRT</a></span>
							<h3 class="price">Rp 580,000</h3>
						</div>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/LENOVO-S20-30-Touch-290x200.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">LENOVO U530 TOUCH</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">JACKET</a></span>
							<h3 class="price">Rp 12,759,000</h3>
						</div>
						<span class="featured">FEATURED</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/SONY-KDL48W605BBAEP-290x200.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">SONY KDL48W605</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">SWEATER</a></span>
							<h3 class="price">Rp 7,000,000</h3>
						</div>
					</div>
				</div>
			</div>
		</div>
				
		
		<div class="row">
			<div class="col-12">
				<div class="pagination">
					<a href="index.php?p=product">&laquo;</a>
					<a href="index.php?p=product">1</a>
					<a href="#" class="active">2</a>
					<a href="index.php?p=product3">3</a>
					<a href="index.php?p=product3">&raquo;</a>
				</div>
			</div>
		</div>
	
	</div>
	
	<!-- content -->