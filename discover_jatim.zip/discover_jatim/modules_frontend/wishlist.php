<!-- content -->
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-12">
				<div class="title-content">
					<strong>MY WISHLIST</strong>
					<small class="small-title-content">YOUR FAVORITE LIST OF PRODUCTS</small>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-12">
				<div class="wishlist">
					<table class="table table-hover">
						<thead>
							<tr>
								<th width="8%">NO</th>
								<th>PICTURE</th>
								<th class="product_table">PRODUCT NAME</th>
								<th width="15%">STOCK STATUS</th>
								<th width="20%">ADD TO CART</th>
							<tr>
						</thead>
						<tbody>
							<tr>
								<td>1.</td>
								<td class="product_table_img" width="15%">
								<img src="resources/images/APPLE-MacBook-Pro-13-3-Zoll.png">
								</td>
								<td class="product_table">
									<h2>MACBOOK PRO 13"</h2>
									<b>Rp 13,175 K</b><a>Rp 13,500 K</a>
								</td>
								<td>IN STOCK</td>
								<td>
									<button class="table_cart" type="submit">+ ADD TO CART</button>
									<span class="close_wish">&times;</span>
								</td>
							<tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
				
	</div>
	
	<!-- content -->