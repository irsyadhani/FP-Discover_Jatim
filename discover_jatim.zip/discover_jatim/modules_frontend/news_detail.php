<!-- content -->
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		
		<?php
			$id_news = base64_decode($_GET['id']);
			$sql = $db->prepare("SELECT * FROM news WHERE id_news = :id_news ");
			$sql->bindParam(':id_news', $id_news);
			$sql->execute();
			
			$hasil = $sql->fetch(PDO::FETCH_ASSOC);
			$path = "resources/images/news/";
		?>
		<div class="row">
			<div class="col-6">
				<div class="title-content">
					<strong>NEWS</strong>
					<small class="small-title-content"><?php echo $hasil['title']; ?></small>
				</div>
			</div>
			<div class="col-6">
				<div class="title-content">
					<small class="small-title-bread"><a href="index.php?p=news">BLOG</a> &raquo; <a href=""><?php echo $hasil['title']; ?></a></small>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-12">
				<div class="news">
					<div class="news-image">
					<img src="<?php echo $path.$hasil['picture']; ?>">
					</div>
					<div class="news-info">
						<h1><a href=""><?php echo $hasil['title']; ?></a></h1>
						<div class="time_news_detail">&#9200; <i style="top:-2px; position:relative;"><?php echo date("d/M/y", strtotime($hasil['created_at'])); ?></i></div>
						<p class="content-info" style="text-align:justify;"><?php echo nl2br($hasil['description']); ?></p>
					</div>
					<div class="news_comment">
						<div class="title-comment">
							<h2>REPLY TO ARTICLE</h2>
							<?php if(@$_SESSION['username'] =="") {?>
								<h6>YOU SHOULD HAVE AN ACCOUNT OR LOGIN FOR COMMENT</h6>
							<?php } ?>
						</div>
						<div>
							<form method="post" action="modules_frontend/proses_comment.php">
								<input type="hidden" name="proc" value="add">
								<input type="hidden" name="id_news" value="<?php echo $hasil['id_news']; ?>">
								<?php if(@$_SESSION['picture'] =="") {?>
								<input type="hidden" name="picture" value="<?php echo "empty.png"; ?>">
								<?php }else{ ?>
								<input type="hidden" name="picture" value="<?php echo @$_SESSION['picture']; ?>">
								<?php } ?>
								<input type="hidden" name="user" value="<?php echo @$_SESSION['username']; ?>">
								<input type="hidden" name="email" value="<?php echo @$_SESSION['email']; ?>">
								<textarea class="textarea-big" rows="5" name="message" type="text" placeholder="Message :" required></textarea>
								<button type="reset" class="button_comment_news_reset">Reset</button>
								<?php if(@$_SESSION['username'] !="") {?>
									<button type="submit" class="button_comment_news">Comment</button>
								<?php }else{ ?>
									<a href="index.php?p=regandlog&idcomment=<?php echo base64_encode($hasil['id_news']); ?>"><button type="button" class="button_comment_news">Comment</button></a>
								<?php } ?>
							</form>
						</div>
						<?php
							$sql = $db->prepare("SELECT id_news FROM comment WHERE id_news = '$id_news'");
							$sql->execute();			
						?>
						<div class="title-comment_reviews">
							<h2><?php echo $sql->rowCount();?> COMMENT</h2>
						</div>
						<?php
							$sql = $db->prepare("SELECT * FROM comment WHERE id_news = '$id_news' ");
							$sql->execute();
							
							while($hasil = $sql->fetch(PDO::FETCH_ASSOC)){
							$path = "resources/images/profil_user/";
						?>
								<div class="fill_reviews">
									<div class="name_review">
										<img src="<?php echo $path.@$hasil['picture']?>">
									<h4 class="name_comment">
										<?php echo @$hasil['user']; ?></h4>
									</div>
									<div class="comment_review">
									<?php echo nl2br($hasil['message']); ?>
									<div class="time_message">
										&#9200; <i><?php echo date("d/M/Y", strtotime($hasil['created_at']))?></i>
									</div>
									</div>
								</div>
						<?php } ?>
					</div>
				</div>
			</div>
		</div>
	
	</div>
	
	<!-- content -->