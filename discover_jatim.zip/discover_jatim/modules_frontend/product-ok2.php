
	<!-- content -->
	<div class="container">
		<div class="row">
			<div class="col-4">
				<div class="banner-up">
					<img src="resources/images/banner/bohemian.jpg">
					<span class="tooltip"><a href=""><b>SHOP NOW</b></a></span>
				</div>
				<div class="banner-up2">
					<img src="resources/images/banner/high_heels.jpg">
					<span class="tooltip"><a href=""><b>SHOP NOW</b></a></span>
				</div>
			</div>
			<div class="col-4">
				<div class="banner-center">
					<img src="resources/images/banner/electronic.jpg">
					<span class="tooltip"><a href=""><b>SHOP NOW</b></a></span>
				</div>
			</div>
			<div class="col-4">
				<div class="banner-up">
					<img src="resources/images/banner/watch.jpg">
					<span class="tooltip"><a href=""><b>SHOP NOW</b></a></span>
				</div>
				<div class="banner-up2">
					<img src="resources/images/banner/sneakers.jpg">
					<span class="tooltip"><a href=""><b>SHOP NOW</b></a></span>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-12">
				<div class="trash_content">
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-12">
				<div class="title-content">
					<strong>PRODUCT	</strong>
					<small class="small-title-content">CHECK IT OUT NOW</small>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href="index.php?p=macbook"><img src="resources/images/APPLE-MacBook-Pro-13-3-Zoll.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="index.php?p=macbook">MACBOOK PRO 13"</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">LAPTOP</a></span>
							<h3 class="price">Rp 13,175,000</h3>
						</div>
						<span class="sale">SALE!</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/BEATS-Beats-by-Dr.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">BEATS BY DRE</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">HEADPHONE</a></span>
							<h3 class="price">Rp 700,000</h3>
						</div>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href="index.php?p=canon"><img src="resources/images/CANON-EOS-700D-18-55mm-IS-STM-8.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="index.php?p=canon">CANON EOS 600D</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">CAMERA</a></span>
							<h3 class="price">Rp 6,175,000</h3>
						</div>
						<span class="disc">5% OFF</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/SAMSUNGS5-UE55H6270.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">SAMSUNG GALAXY S5</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">SMARTPHONE</a></span>
							<h3 class="price">Rp 6,000,000</h3>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/TOSHIBA-32L3443DG.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">TOSHIBA 32L3443DG</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">TV</a></span>
							<h3 class="price">Rp 2,400,000</h3>
						</div>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/image_glasses.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">GLASSES</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">ACCESSORIES</a></span>
							<h3 class="price">Rp 79,000</h3>
						</div>
						<span class="sale">SALE!</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/dkny.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">DKNY</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">BAG</a></span>
							<h3 class="price">Rp 700,000</h3>
						</div>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/asap_bag.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">ASAP BAG</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">BAG</a></span>
							<h3 class="price">Rp 405,000</h3>
						</div>
						<span class="disc">10% OFF</span>
					</div>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/CANON-MG-6450-PIXMA.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">CANON PIXMA MG</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">PRINTER</a></span>
							<h3 class="price">Rp 1500,000</h3>
						</div>
						<span class="featured">FEATURED</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/wd-my-passportu00ae-ultrau2122-1.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">WD MY PASSPORT</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">HARDISK EKSTERNAL</a></span>
							<h3 class="price">Rp 1,200,000</h3>
						</div>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/barcelet.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">PAUL SMITH</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">ACCESSORIES</a></span>
							<h3 class="price">Rp 90,000</h3>
						</div>
						<span class="featured">FEATURED</span>
					</div>
				</div>
			</div>
			<div class="col-3">
				<div class="whole-product">
					<div class="item">
						<div class="item-image">
							<a href=""><img src="resources/images/watch_product.png" width="263" width="196"></a>
						</div>
						<div class="item-info">
							<h3><a href="">STONE DETAIL</a></h3><h3 class="button_cart" title="Add To Cart"><a href="">&#10133;</a></h3>
							<span class="type"><a href="">ACCESSORIES</a></span>
							<h3 class="price">Rp 200,000</h3>
						</div>
						<span class="disc">50% OFF</span>
					</div>
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-12">
				<div class="pagination">
					<a href="#">&laquo;</a>
					<a href="#" class="active">1</a>
					<a href="index.php?p=product2">2</a>
					<a href="#">3</a>
					<a href="index.php?p=product2.html">&raquo;</a>
				</div>
			</div>
		</div>
	
	</div>
	
	<!-- content -->