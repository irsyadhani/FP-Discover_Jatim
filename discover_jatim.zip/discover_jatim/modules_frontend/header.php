<?php include("database.php");?>
<?php session_start();?>
<html>
<head>
	<title>IRZ STORE</title>
	<meta name="viewport" content="width=device-width, initial scale=1">
	<link rel="stylesheet" type="text/css" href="includes/frontend/css/style.css">
	<link rel="shortcut icon" href="resources/images/logo/irzstorelogo2.png">
</head>
<body>
	<!-- header -->
	<header class="large">
		<div class="top-menu">
			<div class="container">
				<div class="row">
					<div class="col-6">
						<li><a href="index.php?p=regandlog">LOGIN</a> or <a href="index.php?p=regandlog">REGISTER</a><span class="sep">|</span><a><?php echo date("l, d/M/Y");?></a></li>
					</div>
					<div class="col-6">
						<li class="menu-right">
						<a href="index.php?p=wishlist">WISHLIST</a><span class="sep">|</span>
						<a href="index.php?p=stores">STORE</a><span class="sep">|</span>
							<?php if(@$_SESSION['username'] !=""){ ?>
							<?php
								$sql = $db->prepare ("SELECT id_user, username, email, password, picture FROM user WHERE username = '$_SESSION[username]'");
								$sql->execute();
								
								$hasil = $sql->fetch(PDO::FETCH_ASSOC)
							?>
							<?php 
								if($hasil['picture'] == '') $hasil['picture'] = 'empty.png';
								$path = "resources/images/profil_user/";
							?>
							<a class="focus_account"><?php echo @$hasil['username'];?>
								<span class="profil_user">
									<div class="circle_profil">
										<?php if(file_exists($path.@$hasil['picture'])) { ?>
											<form method="post" action="modules_frontend/proses_register.php" enctype="multipart/form-data">
												<input type="hidden" name="proc" value="edit">
												<input type="file" name="picture" id="change_profil" style="display:none;">
												<label for="change_profil">
													<img src="<?php echo $path.@$hasil['picture']?>">
												</label>
												<input type="submit" value="CHANGE" class="sub_profil">
											</form>
										<?php } ?>
									</div>
									<div class="name_profil">
										<?php echo @$hasil['username']; ?>
									</div>
									<div class="button_logout">
										<form 
										<?php if(@$_GET['p'] =="news") {?>
											action="modules_frontend/logout.php?p=news"
										<?php }else{ ?>
											action="modules_frontend/logout.php"
										<?php } ?>
										>
											<button type="text">LOGOUT</button>
										</form>
									</div>
								</span>
							</a>
							<?php }else{ ?>
								<a href="index.php?p=regandlog">MY ACCOUNT</a>
							<?php } ?>
						</li>
					</div>
				</div>
			</div>
		</div>
		
		<div class="top-menu2">
			<div class="container">
				<div class="row">
					<div class="col-3">
						<div class="logo">
							<a href="index.php">
							<img src="resources/images/logo/irzstorelogo.png" width="200px" height="35px">
							</a>
						</div>
					</div>
					<div class="col-7">
						<nav class="nav">
							<ul>
								<li>
									<a href="index.php"><i <?php if(@$_GET['p'] == '') echo 'class="active"'; elseif(@$_GET['p'] =="regandlog") echo'class="active"';?>>HOME</i></a>
								</li>
								<li>
									<a href="?p=product"><i 
									<?php
										if(@$_GET['p'] == 'product') {
											echo 'class="active"'; 
										}elseif(@$_GET['p'] == 'macbook'){
											echo'class="active"';
										}elseif(@$_GET['p'] == 'product_detail'){
											echo'class="active"';
										}elseif(@$_GET['p'] == 'cool_kids'){
											echo'class="active"';
										}elseif(@$_GET['p'] == 'product2'){
											echo'class="active"';
										}elseif(@$_GET['p'] == 'product3'){
											echo'class="active"';
										}elseif(@$_GET['p'] == 'canon'){
											echo'class="active"';
										}elseif(@$_GET['p'] == 'cheap_monday'){
											echo'class="active"';
										}
									?>
									>PRODUCT</i></a>
									<ul>
										<?php
											$sql = $db->prepare("SELECT *, A.name AS namesort, B.name AS namecategory FROM sort AS A LEFT JOIN category AS B ON(A.id_category = B.id_category) WHERE A.id_category = '1' ");
											$sql->execute();
											$hasil = $sql->fetch(PDO::FETCH_ASSOC);
										?>
										<li class="image"><a href="#"><img src="resources/images/icon/electronic_icon.png" width="60px" height="60px"></a></li>
										<li class="sili"><a href="index.php?p=product&id_category=<?php echo $hasil['id_category']; ?>"><?php echo $hasil['namecategory']; ?></a></li>
										<?php
											$sql = $db->prepare("SELECT *, A.name AS namesort, B.name AS namecategory FROM sort AS A LEFT JOIN category AS B ON(A.id_category = B.id_category) WHERE A.id_category = '1' LIMIT 0,5");
											$sql->execute();
											while($hasil = $sql->fetch(PDO::FETCH_ASSOC)){
										?>
										<li><a href="index.php?p=product&id_sort=<?php echo @$hasil['id_sort']; ?>"><?php echo @$hasil['namesort']; ?></a></li>
										<?php } ?>
									</ul>
									<ul class="mar2">
										<?php
											$sql = $db->prepare("SELECT *, A.name AS namesort, B.name AS namecategory FROM sort AS A LEFT JOIN category AS B ON(A.id_category = B.id_category) WHERE A.id_category = '4' ");
											$sql->execute();
											$hasil = $sql->fetch(PDO::FETCH_ASSOC);
										?>
										<li class="image"><a href="#"><img src="resources/images/icon/accessories.png" width="60px" height="60px"></a></li>
										<li class="sili"><a href="index.php?p=product&id_category=<?php echo @$hasil['id_category']; ?>"><?php echo $hasil['namecategory']; ?></a></li>
										<?php
											$sql = $db->prepare("SELECT *, A.name AS namesort, B.name AS namecategory FROM sort AS A LEFT JOIN category AS B ON(A.id_category = B.id_category) WHERE A.id_category = '4' LIMIT 0,5");
											$sql->execute();
											while($hasil = $sql->fetch(PDO::FETCH_ASSOC)){
										?>
										<li><a href="index.php?p=product&id_sort=<?php echo @$hasil['id_sort']; ?>"><?php echo @$hasil['namesort']; ?></a></li>
										<?php } ?>
									</ul>
									<ul class="mar3">
										<li class="image-big"><a href="index.php?p=product_detail&id=OA=="><img src="resources/images/banner/CANON-EOS-700D_banner.png" width="236" height="170"></a></li>
									</ul>
								</li>
								
								<li>
									<a href="?p=news"><i 
									<?php 
										if(@$_GET['p'] == ("news")) {
											echo 'class="active"';
										}elseif(@$_GET['p'] == ("news_detail")){
											echo 'class="active"';
										}
									?>
									>BLOG</i></a>
								</li>
								<li>
									<a href="?p=stores"><i <?php if(@$_GET['p'] == 'stores') echo 'class="active"'; ?>>STORES</i></a>
								</li>
							</ul>
						</nav>
					</div>
					<div class="col-2">
						
						<form>
							<input class="ani" type="search" placeholder="Search...">
							<button type="submit" class="search_button">&#128269;</button>
						</form>
							<a href="index.php?p=cart">
								<img class="cart-icon" src="resources/images/icon/shoping_cart.png" width="30px" height="30px">
							</a>
						<span class="circle-cart">1</span>
					</div>
				</div>
			</div>
		</div>
	</header>
	<!-- header -->